//
//  UIView+STExtension.h
//  STYBuy
//
//  Created by 高欣 on 2018/12/26.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (STExtension)
/**
 加入购物车的动画效果
 
 @param goodsImage 商品图片
 @param startPoint 动画起点
 @param endPoint   动画终点
 @param completion 动画执行完成后的回调
 */
- (void)addToShoppingCartWithGoodsImage:(UIImage *)goodsImage startPoint:(CGPoint)startPoint endPoint:(CGPoint)endPoint completion:(void (^)(void))completion;

/**
 *  摇晃动画
 */
- (void)shakeAnimation;
@end

NS_ASSUME_NONNULL_END
