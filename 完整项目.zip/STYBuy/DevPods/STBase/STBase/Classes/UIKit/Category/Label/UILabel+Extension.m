//
//  UILabel+Extension.m
//  STYBuy
//
//  Created by 高欣 on 2018/6/27.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#import "UILabel+Extension.h"

@implementation UILabel (Extension)
+ (instancetype)labelWithColor:(UIColor *)color font:(UIFont *)font alignment:(NSTextAlignment)alignment title:(NSString *)title
{
    return [self labelWithColor:color font:font alignment:alignment title:title numberOfLines:1];
}

+ (instancetype)labelWithColor:(UIColor *)color font:(UIFont *)font alignment:(NSTextAlignment)alignment title:(NSString *)title numberOfLines:(NSInteger)numberOfLines
{
    UILabel *label = [[UILabel alloc] init];
    label.text = title;
    label.textColor = color;
    label.font = font;
    label.textAlignment = alignment;
    label.numberOfLines = numberOfLines;
    return label;
}

+ (instancetype)labelWithColor:(UIColor *)color font:(UIFont *)font alignment:(NSTextAlignment)alignment title:(NSString *)title cornerRadius:(NSInteger)cornerRadius backgroundColor:(UIColor *)backgroundColor
{
    UILabel *label = [self labelWithColor:color font:font alignment:alignment title:title];
    label.backgroundColor = backgroundColor;
    label.layer.cornerRadius = cornerRadius;
    label.layer.masksToBounds = YES;
    return label;
}@end
