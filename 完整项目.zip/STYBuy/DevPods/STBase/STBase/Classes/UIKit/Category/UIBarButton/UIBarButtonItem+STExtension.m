//
//  UIBarButtonItem+STExtension.m
//  STYBuy
//
//  Created by 高欣 on 2019/1/6.
//  Copyright © 2019年 getElementByYou. All rights reserved.
//

#import "UIBarButtonItem+STExtension.h"
#import <objc/runtime.h>

@interface UIBarButtonItem ()

@property (nonatomic,copy) void (^ClickBlock) (UIButton * sender);

@end

@implementation UIBarButtonItem (STExtension)

- (void)setClickBlock:(void (^)(UIButton *))ClickBlock
{
    objc_setAssociatedObject(self, @selector(ClickBlock), ClickBlock, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (void (^)(UIButton *))ClickBlock
{
    return objc_getAssociatedObject(self, @selector(ClickBlock));
}

+ (instancetype)st_customNavBarButton:(UIColor *)titleColor font:(UIFont *)font title:(NSString *)title clickBlock:(void (^) (UIButton * sender))clickBlock
{
    UIButton * button = [UIButton buttonWithTextColor:titleColor font:font];
    if (title && font) {
        CGSize size = [title sizeWithFont:font];
        button.frame = CGRectMake(0, 0, size.width + 10, 40);
    }
    
    if(title) [button setTitle:title forState:UIControlStateNormal];
    
    UIBarButtonItem * barbutton = [[UIBarButtonItem alloc]initWithCustomView:button];
    [button addTarget:barbutton action:@selector(st_addTarget:) forControlEvents:UIControlEventTouchUpInside];
    if (clickBlock) {
        barbutton.ClickBlock = clickBlock;
    }
    return barbutton;
}

- (void)st_addTarget:(UIBarButtonItem *)sender
{
    if (self.ClickBlock) {
        self.ClickBlock(sender);
    }
}

+ (instancetype)st_customNavBarButton:(NSString *)imgName clickBlock:(void (^) (UIButton * sender))clickBlock
{
    UIButton *btn = [[UIButton alloc] init];
    UIBarButtonItem * barbutton = [[UIBarButtonItem alloc]initWithCustomView:btn];
    if (clickBlock) {
        barbutton.ClickBlock =  clickBlock;
    }
    [btn addTarget:barbutton action:@selector(st_addTarget:) forControlEvents:UIControlEventTouchUpInside];
    btn.frame = CGRectMake(0, 0, 40, 40);
    [btn setImage:[[UIImage imageNamed:imgName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
    btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    return barbutton;
}

@end
