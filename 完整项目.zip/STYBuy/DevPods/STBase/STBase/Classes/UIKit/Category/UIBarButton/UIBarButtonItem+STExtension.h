//
//  UIBarButtonItem+STExtension.h
//  STYBuy
//
//  Created by 高欣 on 2019/1/6.
//  Copyright © 2019年 getElementByYou. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIBarButtonItem (STExtension)

+ (instancetype)st_customNavBarButton:(UIColor *)titleColor font:(UIFont *)font title:(NSString *)title clickBlock:(void (^) (UIButton * sender))clickBlock;

+ (instancetype)st_customNavBarButton:(NSString *)imgName clickBlock:(void (^) (UIButton * sender))clickBlock;

@end

NS_ASSUME_NONNULL_END
