# STBase

[![CI Status](https://img.shields.io/travis/LifeForLove/STBase.svg?style=flat)](https://travis-ci.org/LifeForLove/STBase)
[![Version](https://img.shields.io/cocoapods/v/STBase.svg?style=flat)](https://cocoapods.org/pods/STBase)
[![License](https://img.shields.io/cocoapods/l/STBase.svg?style=flat)](https://cocoapods.org/pods/STBase)
[![Platform](https://img.shields.io/cocoapods/p/STBase.svg?style=flat)](https://cocoapods.org/pods/STBase)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

STBase is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'STBase'
```

## Author

LifeForLove, getElementByYou@163.com

## License

STBase is available under the MIT license. See the LICENSE file for more info.
