//
//  HMTipView.m
//  TianYiMerchant
//
//  Created by 高欣 on 2018/10/31.
//  Copyright © 2018年 HLM. All rights reserved.
//

#import "HMTipView.h"
#import <Masonry/Masonry.h>
#import <MJRefresh/MJRefresh.h>


@implementation HMTipView
+ (instancetype)shareTipView
{
    static HMTipView *obj;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        obj = [[HMTipView alloc]init];
        obj.edgeInsets = UIEdgeInsetsMake(8, 20, 8, 20);
        obj.layer.cornerRadius = 17.5;
        obj.layer.masksToBounds = YES;
        obj.textColor = [UIColor whiteColor];
        obj.font = [UIFont systemFontOfSize:13];
        obj.backgroundColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1];
        obj.textAlignment = NSTextAlignmentCenter;
        obj.numberOfLines = 0;
    });
    return obj;
}

+ (void)show:(NSString *)title
{
    void (^finsh)(void) = nil;
    __weak typeof(self)weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        [weakSelf show:title finishBlock:finsh];
    });
}

+ (void)show:(NSString *)title finishBlock:(void (^) (void))finishBlock
{
    title = title ?: @"";
    if (![title isKindOfClass:[NSString class]]) {
        title = @"";
    }
    
    HMTipView * tip = [HMTipView shareTipView];
    tip.text = title;
    UIView * topView = [self getCurrentVC].view;
    topView.userInteractionEnabled = NO;
    [topView addSubview:tip];
    tip.alpha = 0;
    [tip mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(topView);
        make.width.mas_lessThanOrEqualTo([UIScreen mainScreen].bounds.size.width - 50);
        make.height.mas_greaterThanOrEqualTo(35);
    }];
    
    [UIView animateWithDuration:0.2 animations:^{
        tip.alpha = 1;
    } completion:^(BOOL finished) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            topView.userInteractionEnabled = YES;
            [tip removeFromSuperview];
            if (finishBlock) {
                finishBlock();
            }
        });
    }];
}

@end
