//
//  HMTipView.h
//  TianYiMerchant
//
//  Created by 高欣 on 2018/10/31.
//  Copyright © 2018年 HLM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SFLabel.h"

/**
 HUD
 */
#define HUD(text) \
[HMTipView show:text];\
\

#define HUDWithFinish(text,block) \
[HMTipView show:text finishBlock:block];\
\

NS_ASSUME_NONNULL_BEGIN

@interface HMTipView : SFLabel

+ (void)show:(NSString *)title;

+ (void)show:(NSString *)title finishBlock:(void (^) (void))finishBlock;

@end

NS_ASSUME_NONNULL_END
