//
//  STEmptyView.m
//  STYBuy
//
//  Created by 高欣 on 2018/6/28.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#import "STEmptyView.h"
#import <Masonry/Masonry.h>
@interface STEmptyView()

/**
 文字描述label
 */
@property (nonatomic,strong) UILabel *desLabel;

@property (nonatomic,strong) UIImageView *emptyImg;

@property (nonatomic,strong) UIButton *button;

@end


@implementation STEmptyView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.emptyType = STEmptyType_NoData;
    }
    return self;
}

- (void)setEmptyType:(STEmptyType)emptyType
{
    _emptyType = emptyType;
    switch (emptyType) {
        case STEmptyType_NoData:
            self.desLabel.text = @"暂无内容";
            self.emptyImg.image = [UIImage imageNamed:@"empty_nodata"];
            break;
            
        case STEmptyType_NoNetWork:
            self.desLabel.text = @"网络连接失败";
            self.emptyImg.image = [UIImage imageNamed:@"empty_nonet"];
            break;
            
        case STEmptyType_TimedOut:
            self.desLabel.text = @"请求超时";
            self.emptyImg.image = [UIImage imageNamed:@"empty_timeout"];
            break;
            
        case STEmptyType_ErrorDefault:
            self.desLabel.text = @"请求失败";
            self.emptyImg.image = [UIImage imageNamed:@"empty_error"];
            break;
            
        case STEmptyType_Error_Null:
            self.desLabel.text = @"出错啦";
            self.emptyImg.image = [UIImage imageNamed:@"empty_error"];
            [self.button setTitle:@"点击刷新" forState:UIControlStateNormal];
            [self.button setBackgroundColor:[UIColor grayColor]];
            break;
        case STEmptyType_NoOrder:
            self.desLabel.text = @"暂无订单";
            self.emptyImg.image = [UIImage imageNamed:@"empty_nodata"];
            break;
        default:
            break;
    }
}

- (void)bindSelectorForButton:(SEL)selector target:(id)target
{
    if (_button) {
        [_button addTarget:target action:selector forControlEvents:UIControlEventTouchUpInside];
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    switch (self.emptyType) {
        case STEmptyType_Error_Null:
        {
            //有button的情况
            [self addConstraint_normal];
            [self addConstraint_button];
        }
            break;
        default:
            [self addConstraint_normal];
            break;
    }
}

- (void)addConstraint_normal
{
    [self addConstraint:[NSLayoutConstraint constraintWithItem:_desLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:_desLabel attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:_desLabel attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationLessThanOrEqual toItem:self attribute:NSLayoutAttributeWidth multiplier:1 constant:kScreen_width - 60]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:_emptyImg attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:_desLabel attribute:NSLayoutAttributeTop multiplier:1 constant:-30]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:_emptyImg attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
}

- (void)addConstraint_button
{
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.button attribute:NSLayoutAttributeWidth relatedBy:0 toItem:nil attribute:0 multiplier:1 constant:100]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.button attribute:NSLayoutAttributeHeight relatedBy:0 toItem:nil attribute:0 multiplier:1 constant:44]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.button attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.desLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:30]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
}


- (UILabel *)desLabel
{
    if (_desLabel == nil) {
        _desLabel = [[UILabel alloc]init];
        _desLabel.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1];
        _desLabel.font = [UIFont systemFontOfSize:14];
        _desLabel.numberOfLines = 0;
        _desLabel.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:_desLabel];
    }
    return _desLabel;
}

- (UIImageView *)emptyImg
{
    if (_emptyImg == nil) {
        _emptyImg = [[UIImageView alloc]init];
        _emptyImg.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:_emptyImg];
    }
    return _emptyImg;
}

- (UIButton *)button
{
    if (_button == nil) {
        _button = [[UIButton alloc]init];
        _button.titleLabel.font = [UIFont systemFontOfSize:14];
        [_button setTitleColor:[UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1] forState:UIControlStateNormal];
        _button.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:_button];
    }
    return _button;
}

@end
