//
//  GXPageScrollView.h
//  TianYiMerchant
//
//  Created by 高欣 on 2018/8/22.
//  Copyright © 2018年 HLM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GXPageViewConfig : NSObject

/**
 分页子视图(必传)
 */
@property (nonatomic,strong) NSArray *childViewControllers;

/**
 区标题(必传)
 */
@property (nonatomic,strong) NSArray *sectionTitleArr;

/**
 区标题Font
 */
@property (nonatomic,strong) UIFont *sectionTitleFont;

/**
 区标题默认颜色
 */
@property (nonatomic,strong) UIColor *sectionTitleColor_Normal;
/**
 区标题选中颜色
 */
@property (nonatomic,strong) UIColor *sectionTitleColor_Select;

/**
 区标题文字之间的间隔
 */
@property (nonatomic,assign) NSInteger spacingBetweenButtons;

/**
 标题栏的高度
 */
@property (nonatomic,assign) NSInteger sectionH;

/**
 指示器颜色
 */
@property (nonatomic,strong) UIColor *indicatorColor;

/**
 区底部分割线
 */
@property (nonatomic,strong) UIColor *sectionBottomLineColor;

/**
 指示器高度
 */
@property (nonatomic,assign) NSInteger indicatorH;


/**
 设置滚动到那个区 默认值为:0
 */
@property (nonatomic,assign) NSInteger scrollIndex;

/**
 是否不能滚动
 */
@property (nonatomic,assign) BOOL canNotScroll;

@end

@protocol GXPageScrollViewDelegate <NSObject>

/**
 点击标题回调该方法

 @param index d对应的角标
 */
- (void)sectionTitleSelect:(NSInteger)index;

@end


@interface GXPageScrollView : UIView

/**
 当前选中的角标
 */
@property (nonatomic,assign) NSInteger currentSelectIndex;

/**
 更改角标的值

 @param index 要更改的角标
 @param pointVaule 角标的值
 */
- (void)changeRedPointVauleWithIndex:(NSInteger)index pointVaule:(NSString *)pointVaule;

/**
 重新设置title的文字
 */
- (void)setTitleLabelText:(NSString *)title index:(NSInteger)index;

/**
 滚动到哪个区

 @param index 角标
 */
- (void)setPageContentScrollViewIndex:(NSInteger)index;

- (instancetype)initWithFrame:(CGRect)frame config:(GXPageViewConfig *)config;

@property (nonatomic,weak) id<GXPageScrollViewDelegate> delegate;


@end

