//
//  GXPageScrollView.m
//  TianYiMerchant
//
//  Created by 高欣 on 2018/8/22.
//  Copyright © 2018年 HLM. All rights reserved.
//

#import "GXPageScrollView.h"
#import <MJRefresh/MJRefresh.h>
@protocol GXPageSectionViewDelegate <NSObject>

/**
 改变区域的回调

 @param area 当前区域
 */
- (void)pageViewChangeArea:(NSInteger)area;

@end

@interface GXPageSectionView :UIView


@property (nonatomic,strong) UIScrollView *scrollView;

/**
 指示条
 */
@property (nonatomic,strong) UIView *indicatorView;

/**
 底部分割线
 */
@property (nonatomic,strong) UIView *bottomLine;

/**
 存储标题按钮的数组
 */
@property (nonatomic,strong) NSMutableArray *btnArr;

/**
 配置信息
 */
@property (nonatomic,strong) GXPageViewConfig *config;

/**
 标签是否需要滚动
 */
@property (nonatomic,assign) BOOL needScroll;

/**
 记录上一次选中的button
 */
@property (nonatomic,strong) UIButton *tempBtn;

@property (nonatomic,weak) id<GXPageSectionViewDelegate> delegate;


- (void)setPageTitleViewWithProgress:(CGFloat)progress originalIndex:(NSInteger)originalIndex targetIndex:(NSInteger)targetIndex;
@end

@implementation GXPageSectionView

- (instancetype)initWithFrame:(CGRect)frame config:(GXPageViewConfig *)config
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        self.config = config;
        [self creatView];
    }
    return self;
}

- (void)creatView
{
    [self addSubview:self.scrollView];
    [self addSectionButton];
    [self addSubview:self.bottomLine];
    [self.scrollView insertSubview:self.indicatorView atIndex:0];
}

- (void)addSectionButton
{
    CGFloat allBtnTextWidth = 0;
    for (int i = 0; i < self.config.sectionTitleArr.count; i++) {
        CGFloat tempWidth = [self widthWithString:self.config.sectionTitleArr[i]];
        allBtnTextWidth += tempWidth;
    }
    // 所有按钮文字宽度 ＋ 按钮之间的间隔
    CGFloat allBtnWidth = 0;
    allBtnWidth = self.config.spacingBetweenButtons * (self.config.sectionTitleArr.count + 1) + allBtnTextWidth;
    allBtnWidth = ceilf(allBtnWidth);
    self.needScroll = allBtnWidth <= self.mj_w ? NO : YES;
    
    CGFloat btn_x = 0;
    CGFloat btn_y = 0;
    CGFloat btn_w = 0;
    CGFloat btn_h = self.config.sectionH;
    
    self.scrollView.scrollEnabled = allBtnWidth <= self.mj_w ? NO : YES;

    for (int i = 0; i < self.config.sectionTitleArr.count; i++) {
        NSString * sectionTitle = self.config.sectionTitleArr[i];
        CGFloat btnTitleW = [self widthWithString:sectionTitle];
        if (self.needScroll) {
            btn_w = btnTitleW + self.config.spacingBetweenButtons;
        }else
        {
            btn_w = self.mj_w / self.config.sectionTitleArr.count;
        }

        if (i == 0) {
            self.indicatorView.frame = CGRectMake((btn_w - btnTitleW) / 2,self.config.sectionH - self.config.indicatorH - 1, btnTitleW, self.config.indicatorH);
        }
        UIButton * btn = [self sectionButtonWithTitle:sectionTitle];
        btn.tag = i;
        btn.frame = CGRectMake(btn_x, btn_y, btn_w, btn_h);
        btn_x += btn_w;
        [self.scrollView addSubview:btn];
        [self.btnArr addObject:btn];
    }
    self.scrollView.contentSize = CGSizeMake(btn_x, 0);

}


/**
 区标题按钮的点击事件

 @param sender sender
 */
- (void)sectionButtonAction:(UIButton *)sender
{
    //选中当前标题
    [self changeTitleSelectState:sender];
    //更改指示器的位置
    [self changeIndicatorViewLocationWithButton:sender];
    //滚动标题选中居中
    [self scrollButtonCenter:sender];
    //调用代理方法
    if ([self.delegate respondsToSelector:@selector(pageViewChangeArea:)]) {
        [self.delegate pageViewChangeArea:sender.tag];
    }
}

- (void)scrollButtonCenter:(UIButton *)sender
{
    if (self.needScroll) {
        // 计算偏移量
        CGFloat offsetX = sender.center.x - self.mj_w * 0.5;
        if (offsetX < 0) offsetX = 0;
        // 获取最大滚动范围
        CGFloat maxOffsetX = self.scrollView.contentSize.width - self.mj_w;
        if (offsetX > maxOffsetX) offsetX = maxOffsetX;
        // 滚动标题滚动条
        [self.scrollView setContentOffset:CGPointMake(offsetX, 0) animated:YES];
    }
}


/**
 根据文字过去文字宽度

 @param string 文字
 @return 文字宽度
 */
- (CGFloat)widthWithString:(NSString *)string
{
    NSDictionary *attrs = @{NSFontAttributeName : self.config.sectionTitleFont};
    return [string boundingRectWithSize:CGSizeMake(0, 0) options:NSStringDrawingUsesLineFragmentOrigin attributes:attrs context:nil].size.width;
}

/**
 创建标题按钮

 @param sectionTitle 区标题
 @return 按钮
 */
- (UIButton *)sectionButtonWithTitle:(NSString *)sectionTitle
{
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setTitle:sectionTitle forState:UIControlStateNormal];
    btn.titleLabel.font = self.config.sectionTitleFont;
    [btn setTitleColor:self.config.sectionTitleColor_Normal forState:UIControlStateNormal];
    [btn setTitleColor:self.config.sectionTitleColor_Select forState:UIControlStateSelected];
    [btn addTarget:self action:@selector(sectionButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    return btn;
}

- (void)setPageTitleViewWithProgress:(CGFloat)progress originalIndex:(NSInteger)originalIndex targetIndex:(NSInteger)targetIndex
{
    // 1、取出 originalBtn／targetBtn
    UIButton *originalBtn = self.btnArr[originalIndex];
    UIButton *targetBtn = self.btnArr[targetIndex];
    
    // 2、 滚动标题选中居中
    [self scrollButtonCenter:targetBtn];
    // 3、处理指示器的逻辑
    if (self.needScroll) {
        // SGPageTitleView 可滚动
        [self indicatorScrollStyleDefaultWithProgress:progress originalBtn:originalBtn targetBtn:targetBtn];
    } else {
        // 不可滚动
        [self smallIndicatorScrollStyleDefaultWithProgress:progress originalBtn:originalBtn targetBtn:targetBtn];
    }
}

- (void)smallIndicatorScrollStyleDefaultWithProgress:(CGFloat)progress originalBtn:(UIButton *)originalBtn targetBtn:(UIButton *)targetBtn {
    // 1、改变按钮的选择状态
    if (progress >= 0.8) { /// 此处取 >= 0.8 而不是 1.0 为的是防止用户滚动过快而按钮的选中状态并没有改变
        [self changeTitleSelectState:targetBtn];
    }
    
    //
    CGFloat targetBtnX = CGRectGetMaxX(targetBtn.frame) - [self widthWithString:targetBtn.currentTitle] - 0.5 * (self.mj_w / self.config.sectionTitleArr.count - [self widthWithString:targetBtn.currentTitle]);
    CGFloat originalBtnX = CGRectGetMaxX(originalBtn.frame) - [self widthWithString:originalBtn.currentTitle] - 0.5 * (self.mj_w / self.config.sectionTitleArr.count - [self widthWithString:originalBtn.currentTitle]);
    CGFloat totalOffsetX = targetBtnX - originalBtnX;
    
    /// 计算 targetBtn／originalBtn 宽度的差值
    CGFloat targetBtnDistance = (CGRectGetMaxX(targetBtn.frame) - 0.5 * (self.mj_w / self.config.sectionTitleArr.count - [self widthWithString:targetBtn.currentTitle]));
    
    CGFloat originalBtnDistance = (CGRectGetMaxX(originalBtn.frame) - 0.5 * (self.mj_w / self.config.sectionTitleArr.count - [self widthWithString:originalBtn.currentTitle]));
    CGFloat totalDistance = targetBtnDistance - originalBtnDistance;
    
    /// 计算 indicatorView 滚动时 X 的偏移量
    CGFloat offsetX;
    /// 计算 indicatorView 滚动时宽度的偏移量
    CGFloat distance;
    offsetX = totalOffsetX * progress;
    //L两个标题宽度之间的差值
    distance = progress * (totalDistance - totalOffsetX);
    
    /// 计算 indicatorView 新的 frame
    self.indicatorView.mj_x = originalBtnX + offsetX;
    self.indicatorView.mj_w = [self widthWithString:originalBtn.currentTitle] + distance;
}

/// SGPageTitleView 可滚动 - - - SGIndicatorScrollStyleDefault
- (void)indicatorScrollStyleDefaultWithProgress:(CGFloat)progress originalBtn:(UIButton *)originalBtn targetBtn:(UIButton *)targetBtn {
    /// 改变按钮的选择状态
    if (progress >= 0.8) { /// 此处取 >= 0.8 而不是 1.0 为的是防止用户滚动过快而按钮的选中状态并没有改变
        [self changeTitleSelectState:targetBtn];
    }
    
    /// 计算 targetBtn／originalBtn 之间的距离
    CGFloat totalOffsetX = targetBtn.mj_x - originalBtn.mj_x;
    /// 计算 targetBtn／originalBtn 宽度的差值
    CGFloat totalDistance = CGRectGetMaxX(targetBtn.frame) - CGRectGetMaxX(originalBtn.frame);
    /// 计算 indicatorView 滚动时 X 的偏移量
    CGFloat offsetX = 0.0;
    /// 计算 indicatorView 滚动时宽度的偏移量
    CGFloat distance = 0.0;

    offsetX = totalOffsetX * progress + 0.5 * self.config.spacingBetweenButtons;
    distance = progress * (totalDistance - totalOffsetX) - self.config.spacingBetweenButtons;
    /// 计算 indicatorView 新的 frame
    self.indicatorView.mj_x = originalBtn.mj_x + offsetX;
    self.indicatorView.mj_w = originalBtn.mj_w + distance;

}


/**
 点击标题的时候更改指示器的位置

 @param button 点击的按钮
 */
- (void)changeIndicatorViewLocationWithButton:(UIButton *)button {
    [UIView animateWithDuration:0.3 animations:^{
        CGFloat tempIndicatorWidth = [self widthWithString:button.currentTitle];
        if (tempIndicatorWidth > button.mj_w) {
            tempIndicatorWidth = button.mj_w;
        }
        self.indicatorView.mj_w = tempIndicatorWidth;
        self.indicatorView.center = CGPointMake(button.center.x, self.indicatorView.center.y);
    }];
}


/**
 更改选中按钮的状态

 @param sender 要被选中的按钮
 */
- (void)changeTitleSelectState:(UIButton *)sender
{
    if (self.tempBtn == nil) {
        self.tempBtn = sender;
        sender.selected = YES;
    }else
    {
        self.tempBtn.selected = NO;
        sender.selected = YES;
        self.tempBtn = sender;
    }
}


- (NSMutableArray *)btnArr
{
    if (_btnArr == nil) {
        _btnArr = [NSMutableArray array];
    }
    return _btnArr;
}

- (UIScrollView *)scrollView
{
    if (_scrollView == nil) {
        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.mj_w, self.config.sectionH)];
        _scrollView.bounces = YES;
        _scrollView.backgroundColor = self.backgroundColor;
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.showsHorizontalScrollIndicator = NO;
    }
    return _scrollView;
}

- (UIView *)bottomLine
{
    if (_bottomLine == nil) {
        _bottomLine = [[UIView alloc]initWithFrame:CGRectMake(0, self.config.sectionH - 1, self.mj_w, 1)];
        _bottomLine.backgroundColor = self.config.sectionBottomLineColor;
    }
    return _bottomLine;
}

- (UIView *)indicatorView
{
    if (_indicatorView == nil) {
        _indicatorView = [[UIView alloc]init];
        _indicatorView.backgroundColor = self.config.indicatorColor;
    }
    return _indicatorView;
}

@end


@interface GXPageScrollView ()<UIScrollViewDelegate,GXPageSectionViewDelegate>

/**
 标题
 */
@property (nonatomic,strong) GXPageSectionView *sectionView;

@property (nonatomic, strong) UIScrollView *scrollView;

/**
 配置信息
 */
@property (nonatomic,strong) GXPageViewConfig *config;

/**
 开始的x值 用来判断是左滑还是右滑动
 */
@property (nonatomic,assign) CGFloat startOffsetX;

/**
 判断是不是点击
 */
@property (nonatomic,assign) BOOL isClick;

@end


@implementation GXPageScrollView

- (instancetype)initWithFrame:(CGRect)frame config:(GXPageViewConfig *)config
{
    self = [super initWithFrame:frame];
    if (self) {
        self.config = config;
        [self createView];
    }
    return self;
}

- (void)createView
{
    [self addSubview:self.sectionView];
    [self addSubview:self.scrollView];
    self.scrollView.frame = CGRectMake(0, self.config.sectionH, self.mj_w, self.mj_h - self.config.sectionH);
    
    //初始化第一个目标控制器
    [self setPageContentScrollViewIndex:self.config.scrollIndex];
    self.currentSelectIndex = self.config.scrollIndex;
}

/**
 添加子视图
 
 @param index 角标
 */
- (void)setPageContentScrollViewIndex:(NSInteger)index
{
    //设置section选中目标控制器
    [self.sectionView setPageTitleViewWithProgress:1 originalIndex:index targetIndex:index];
    [self.scrollView setContentOffset:CGPointMake(index * self.mj_w , 0) animated:NO];
    CGFloat offsetX = index * self.mj_w;
    [self addChildVC:offsetX];
    
}

/**
 添加子控制器
 
 @param offsetX 偏移量
 */
- (void)addChildVC:(CGFloat)offsetX
{
    NSInteger index = offsetX / self.mj_w;
    //判断是否存在数组越界
    if (index >= self.config.childViewControllers.count) return;
    UIViewController *childVC = self.config.childViewControllers[index];
    // 2、判断控制器的view有没有加载过,如果已经加载过,就不需要加载
    if (childVC.isViewLoaded) return;
    [self.scrollView addSubview:childVC.view];
    childVC.view.backgroundColor = [UIColor whiteColor];
    childVC.view.frame = CGRectMake(index * self.mj_w ,0, self.mj_w, self.mj_h - self.config.sectionH);
}

/**
 开始滑动 记录当前x 值
 */
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    self.isClick = NO;
    self.startOffsetX = scrollView.contentOffset.x;
}

//滚动的 时候调用
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (self.isClick) {
       // [self scrollViewDidEndDecelerating:scrollView];
        return;
    }
    
    // 1、定义获取需要的数据
    CGFloat progress = 0;
    NSInteger originalIndex = 0;
    NSInteger targetIndex = 0;
    // 2、判断是左滑还是右滑
    CGFloat currentOffsetX = scrollView.contentOffset.x;
    CGFloat scrollViewW = scrollView.bounds.size.width;
    if (currentOffsetX > self.startOffsetX) { // 左滑
        // 1、计算 progress
        progress = currentOffsetX / scrollViewW - floor(currentOffsetX / scrollViewW);
        // 2、计算 originalIndex
        originalIndex = currentOffsetX / scrollViewW;
        // 3、计算 targetIndex
        targetIndex = originalIndex + 1;
        if (targetIndex >= self.config.childViewControllers.count) {
            progress = 1;
            targetIndex = originalIndex;
        }
        // 4、如果完全划过去
        if (currentOffsetX - self.startOffsetX == scrollViewW) {
            progress = 1;
            targetIndex = originalIndex;
        }
    } else { // 右滑
        // 1、计算 progress
        progress = 1 - (currentOffsetX / scrollViewW - floor(currentOffsetX / scrollViewW));
        // 2、计算 targetIndex
        targetIndex = currentOffsetX / scrollViewW;
        // 3、计算 originalIndex
        originalIndex = targetIndex + 1;
        if (originalIndex >= self.config.childViewControllers.count) {
            originalIndex = self.config.childViewControllers.count - 1;
        }
    }
    
    [self.sectionView setPageTitleViewWithProgress:progress originalIndex:originalIndex targetIndex:targetIndex];
    //设置当前选中角标
    self.currentSelectIndex = targetIndex;
}


/**
 滚动结束
 */
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    CGFloat offsetX = scrollView.contentOffset.x;
    [self addChildVC:offsetX];
}

/**
 点了section标题 设置分页滚动
 */
- (void)pageViewChangeArea:(NSInteger)area
{
    if ([self.delegate respondsToSelector:@selector(sectionTitleSelect:)]) {
        [self.delegate sectionTitleSelect:area];
    }
    
    self.isClick = YES;
    [self.scrollView setContentOffset:CGPointMake(area * self.mj_w , 0) animated:YES];
    [self addChildVC:area * self.mj_w];
    self.currentSelectIndex = area;
}

/**
 更改角标的值
 
 @param index 要更改的角标
 @param pointVaule 角标的值
 */
- (void)changeRedPointVauleWithIndex:(NSInteger)index pointVaule:(NSString *)pointVaule
{
}

/**
 更新section的标题文字

 @param title 标题
 @param index 对应的角标
 */
- (void)setTitleLabelText:(NSString *)title index:(NSInteger)index
{
    if (index <= self.sectionView.btnArr.count - 1) {
        UIButton * btn = self.sectionView.btnArr[index];
        [btn setTitle:title forState:UIControlStateNormal];
    }
}


- (GXPageSectionView *)sectionView
{
    if (_sectionView == nil) {
        _sectionView = [[GXPageSectionView alloc]initWithFrame:CGRectMake(0, 0, self.mj_w, self.config.sectionH) config:self.config];
        _sectionView.delegate = self;
    }
    return _sectionView;
}


- (UIScrollView *)scrollView {
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] init];
        _scrollView.bounces = NO;
        _scrollView.backgroundColor = self.backgroundColor;
        _scrollView.delegate = self;
        _scrollView.pagingEnabled = YES;
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.scrollEnabled = !self.config.canNotScroll;
        CGFloat contentWidth = self.config.childViewControllers.count * self.mj_w;
        _scrollView.contentSize = CGSizeMake(contentWidth, 0);
    }
    return _scrollView;
}

@end


@implementation GXPageViewConfig

- (UIFont *)sectionTitleFont
{
    if (_sectionTitleFont == nil) {
        _sectionTitleFont = [UIFont systemFontOfSize:15];
    }
    return _sectionTitleFont;
}

- (UIColor *)sectionTitleColor_Normal
{
    if (_sectionTitleColor_Normal == nil) {
        _sectionTitleColor_Normal = [UIColor grayColor];
    }
    return _sectionTitleColor_Normal;
}

- (UIColor *)sectionTitleColor_Select
{
    if (_sectionTitleColor_Select == nil) {
        _sectionTitleColor_Select = [UIColor blackColor];
    }
    return _sectionTitleColor_Select;
}

- (UIColor *)sectionBottomLineColor
{
    if (_sectionBottomLineColor == nil) {
        _sectionBottomLineColor = [UIColor blackColor];
    }
    return _sectionBottomLineColor;
}

- (NSInteger)sectionH
{
    return _sectionH > 0 ?: 44;
}

- (NSInteger)spacingBetweenButtons
{
    return _spacingBetweenButtons > 0 ?:20;
}

- (UIColor *)indicatorColor
{
    if (_indicatorColor == nil) {
        _indicatorColor = [UIColor whiteColor];
    }
    return _indicatorColor;
}

- (NSInteger)indicatorH
{
    return _indicatorH > 0 ?:0;
}

@end

