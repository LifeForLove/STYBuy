//
//  GXRefreshFooter.h
//  MartialMaster
//
//  Created by apple on 2017/10/1.
//  Copyright © 2017年 getElementByYou. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface GXRefreshFooter : MJRefreshAutoGifFooter

@end
