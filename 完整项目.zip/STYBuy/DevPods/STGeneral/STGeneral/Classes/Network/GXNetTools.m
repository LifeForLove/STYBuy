//
//  GXNetTools.m
//  LANGril
//
//  Created by apple on 2017/5/4.
//  Copyright © 2017年 apple. All rights reserved.
//

#import "GXNetTools.h"

@interface GXNetTools ()

@end

@implementation GXNetTools
+ (instancetype)sharedAFNetTool
{
    static GXNetTools *obj;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        obj = [GXNetTools manager];
        obj.responseSerializer = [AFHTTPResponseSerializer serializer];
        obj.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"text/json", @"text/plain", @"application/javascript", @"text/html",nil];
        obj.requestSerializer.timeoutInterval  = 8.0f;
    });
    return obj;
}

+ (void)setRequestHeader
{
}

+ (void)sendRequsetWithMessage:(void (^) (NSObject *message,NSMutableDictionary * dict))requestMessage successBlock:(void(^)(id obj))successBlock errorBlock:(void (^) (NSError * error))errorBlock
{
    [self sendRequsetWithMessage:requestMessage progress:nil successBlock:successBlock errorBlock:errorBlock];
}

+ (void)requsetWithMessage:(NSObject *)message successBlock:(void(^)(id obj))successBlock errorBlock:(void (^) (NSError * error))errorBlock
{
    switch (message.st_method) {
        case STRequestMethodGET:
            [self getInfoWithRequestMessage:message progress:nil andFinish:successBlock andError:errorBlock];
            break;
            
        case STRequestMethodPOST:
            [self postWithRequestMessage:message progress:nil andSuccessBlock:successBlock addErrorBlock:errorBlock];
            break;
            
        default:
            break;
    }
}

+ (void)sendRequsetWithMessage:(void (^)(NSObject *, NSMutableDictionary *))requestMessage progress:(void (^)(NSProgress *))progressBlock successBlock:(void (^)(id))successBlock errorBlock:(void (^)(NSError *))errorBlock
{
    if (requestMessage) {
        NSObject * message = [NSObject new];
        //默认请求格式
        message.st_requestContentType = STRequestHttp;
        // 默认使用post 请求
        message.st_method = STRequestMethodPOST;
        // 默认当后台返回success = 0 时 提示 错误信息
        message.st_success0_showErrorInfo = NO;
        // 默认上传ueseId 和 shopId
//        message.st_needUserIdAndShopId = YES;
        message.st_parameters = [NSMutableDictionary dictionary];
        
        requestMessage(message,message.st_parameters);
        
        //默认所有请求 加上userId
        if (message.st_needUserIdAndShopId) {
        }

        //判断请求连接是否为空
        if (message.st_requestURL == nil) return;
        
        switch (message.st_requestContentType) {
            case STRequestHttp:
            {
                [GXNetTools sharedAFNetTool].requestSerializer = [AFHTTPRequestSerializer serializer];
                //先设置请求头格式，再设置请求头，不然请求头里的数据会被干掉
                [GXNetTools setRequestHeader];
                //加密

            }
                break;
            case STRequestJson:
            {
                [GXNetTools sharedAFNetTool].requestSerializer = [AFJSONRequestSerializer serializer];
                //先设置请求头格式，再设置请求头，不然请求头里的数据会被干掉
                [GXNetTools setRequestHeader];
            }
            default:
                break;
        }
        
        
        switch (message.st_method) {
            case STRequestMethodGET:
                [self getInfoWithRequestMessage:message progress:progressBlock andFinish:successBlock andError:errorBlock];
                break;
                
            case STRequestMethodPOST:
                [self postWithRequestMessage:message progress:progressBlock andSuccessBlock:successBlock addErrorBlock:errorBlock];
                break;
                
            default:
                break;
        }
    }
}



+ (void)getInfoWithRequestMessage:(NSObject *)requestMessage progress:(void (^)(NSProgress *progres))progressBlock andFinish:(void(^)(id obj))successBlock andError:(void (^) (NSError * error))errorBlock
{
    
    if (requestMessage.st_needHUD) {
        dispatch_async(dispatch_get_main_queue(), ^{
//            HUD_LOADING
        });
    }
    [self logParameter:requestMessage.st_parameters withURL:requestMessage.st_requestURL];
    
    [[GXNetTools sharedAFNetTool] GET:requestMessage.st_requestURL parameters:requestMessage.st_parameters progress:^(NSProgress * _Nonnull uploadProgress) {
        if (progressBlock) {
            progressBlock(uploadProgress);
        }
    }success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (requestMessage.st_needHUD) {
//            [SVProgressHUD dismiss];
        }
        
        if (responseObject) {
            if (![responseObject isKindOfClass:[NSDictionary class]]) {
                responseObject = [NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions|NSJSONReadingMutableLeaves | NSJSONReadingMutableContainers | NSJSONReadingAllowFragments error:nil];
            }
            
            NSString *code = responseObject[@"code"];
            //4004  未登录   4006  被挤掉
            if (code != nil && ([code isKindOfClass:[NSString class]] || [code isKindOfClass:[NSNumber class]])) {
                if ([code integerValue] == 4004){
//                    [STUserManager showAlert:@"账号未登录，请重新登录"];
                }else if ([code integerValue] == 4006){
//                    [STUserManager showAlert:@"此账号已在其他设备上登录"];
                }
            }
        }
        
        NSLog(@"get请求结果%@",responseObject);
        
        if ([responseObject[@"success"] integerValue] == 0) {
            //当success = 0 时 提示错误信息
            if (requestMessage.st_success0_showErrorInfo) {
                HUD(responseObject[@"msg"])
            }
            
            //是否只需要success = 1的回调
            if (requestMessage.st_onlySuccess1) {
                return ;
            }
        }
        
        if (successBlock) {
            successBlock(responseObject);
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (requestMessage.st_needHUD) {
//            [SVProgressHUD dismiss];
        }
        NSString *err = [error  userInfo][@"NSLocalizedDescription"];
        if (err) {
            HUD(err)
        }else {
            HUD(@"网络出现问题,请稍后再试");
        }
        if (errorBlock) {
            errorBlock(error);
        }
        //打印error
        [self logError:error];
    }];
    
}



+ (void)postWithRequestMessage:(NSObject *)requestMessage progress:(void (^)(NSProgress *progres))progressBlock andSuccessBlock:(void(^)(id obj))successBlock addErrorBlock:(void (^) (NSError * error))errorBlock
{
    if (requestMessage.st_needHUD) {
        dispatch_async(dispatch_get_main_queue(), ^{
//            HUD_LOADING
        });
    }
    [self logParameter:requestMessage.st_parameters withURL:requestMessage.st_requestURL];
    [[GXNetTools sharedAFNetTool] POST:requestMessage.st_requestURL parameters:requestMessage.st_parameters progress:^(NSProgress * _Nonnull uploadProgress) {
        if (progressBlock) {
            progressBlock(uploadProgress);
        }
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (requestMessage.st_needHUD) {
//            [SVProgressHUD dismiss];
        }
        if (responseObject) {
            if (![responseObject isKindOfClass:[NSDictionary class]])
            {
                responseObject = [NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions|NSJSONReadingMutableLeaves | NSJSONReadingAllowFragments error:nil];
            }
            
            NSString *code = responseObject[@"code"];
            //4004  未登录   4006  被挤掉
            if (code != nil && ([code isKindOfClass:[NSString class]] || [code isKindOfClass:[NSNumber class]])) {
                if ([code integerValue] == 4004){
//                    [STUserManager showAlert:@"账号未登录，请重新登录"];
                }else if ([code integerValue] == 4006){
//                    [STUserManager showAlert:@"此账号已在其他设备上登录"];
                }
            }
        }
        
        //        NSLog(@"post请求结果%@",responseObject);
        NSLog(@"%@ \n post请求结果%@",requestMessage.st_requestURL,responseObject);
        
        if ([responseObject[@"success"] integerValue] == 0) {
            //当success = 0 时 提示错误信息
            if (requestMessage.st_success0_showErrorInfo) {
                HUD(responseObject[@"msg"])
            }
            
            //是否只需要success = 1的回调
            if (requestMessage.st_onlySuccess1) {
                return ;
            }
        }
        
        if (successBlock) {
            successBlock(responseObject);
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (requestMessage.st_needHUD) {
//            [SVProgressHUD dismiss];
        }
        NSString *err = [error  userInfo][@"NSLocalizedDescription"];
        if (err) {
            HUD(err)
        }else {
            HUD(@"网络出现问题,请稍后再试");
        }
        if (errorBlock) {
            errorBlock(error);
        }
        //打印error
        [self logError:error];
    }];
}



+ (void)logParameter:(NSDictionary *)dic withURL:(NSString *)url
{
#ifdef DEBUG
    NSLog(@"参数 %@\n url = %@",dic,url);
#else
    //do sth.
#endif
}


/**
 打印error
 
 @param error error
 */
+ (void)logError:(NSError *)error
{
#ifdef DEBUG
    NSError * error1 = [error userInfo][@"NSUnderlyingError"];
    NSData * data;
    if (!error1) {
        data = error.userInfo[@"com.alamofire.serialization.response.error.data"];
    }else
    {
        data = error1.userInfo[@"com.alamofire.serialization.response.error.data"];
    }
    NSString * str = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"%@",str);
#else
    //do sth.
#endif
}



+ (void)sendRequset:(NSString *)requestUrl message:(id)message successBlock:(void(^)(id obj))successBlock errorBlock:(void (^) (NSError * error))errorBlock
{
    [GXNetTools sharedAFNetTool].requestSerializer = [AFJSONRequestSerializer serializer];
    
    //先设置请求头格式，再设置请求头，不然请求头里的数据会被干掉
    [GXNetTools setRequestHeader];
    //加密(传json格式的接口拼接一个userid，其他参数不用加密)
    
    dispatch_async(dispatch_get_main_queue(), ^{
//        HUD_LOADING
    });
    
    [[GXNetTools sharedAFNetTool] POST:requestUrl parameters:message progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//        [SVProgressHUD dismiss];
        
        if (responseObject) {
            if (![responseObject isKindOfClass:[NSDictionary class]])
            {
                responseObject = [NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions|NSJSONReadingMutableLeaves | NSJSONReadingAllowFragments error:nil];
            }
            
            NSString *code = responseObject[@"code"];
            //4004  未登录   4006  被挤掉
            if (code != nil) {
                if ([code integerValue] == 4004){
//                    [UserProfile showAlert:@"账号未登录，请重新登录"];
                }else if ([code integerValue] == 4006){
//                    [UserProfile showAlert:@"此账号已在其他设备上登录"];
                }
            }
        }
        
        NSLog(@"%@ \n post请求结果%@",requestUrl,responseObject);
        
        if (successBlock) {
            successBlock(responseObject);
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//        [SVProgressHUD dismiss];
        NSString *err = [error  userInfo][@"NSLocalizedDescription"];
        if (err) {
            HUD(err)
        }else {
            HUD(@"网络出现问题,请稍后再试");
        }
        if (errorBlock) {
            errorBlock(error);
        }
        //打印error
        [self logError:error];
    }];
    
}



@end
