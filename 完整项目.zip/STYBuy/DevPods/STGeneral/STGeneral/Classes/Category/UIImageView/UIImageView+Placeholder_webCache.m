//
//  UIImageView+Placeholder_webCache.m
//  TianYiMerchant
//
//  Created by 高欣 on 2018/10/26.
//  Copyright © 2018年 HLM. All rights reserved.
//

#import "UIImageView+Placeholder_webCache.h"

@implementation UIImageView (Placeholder_webCache)

- (void)head_setImageWithString:(NSString *)url
{
    [self sd_setImageWithURL:[NSURL URLWithString:url] placeholderImage:[UIImage imageNamed:@"userhead"]];
}

@end
