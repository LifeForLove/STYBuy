//
//  NSObject+STEmptyView.h
//  STYBuy
//
//  Created by 高欣 on 2019/1/12.
//  Copyright © 2019年 getElementByYou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UIScrollView+EmptyDataSet.h"
#import "STEmptyView.h"
NS_ASSUME_NONNULL_BEGIN

@interface NSObject (STEmptyView)<DZNEmptyDataSetSource,DZNEmptyDataSetDelegate>

/**
 当页面无数据时 展示此视图
 */
@property (nonatomic,readonly) STEmptyView *emptyView;

/**
 当tableView 请求失败时  需要展示空白视图 调用此方法
 
 @param scrollView tableView
 @param error 错误类型 当没有时传nil
 */
- (void)scrollViewConfigRequestStateForEmptyView:(UIScrollView *)scrollView error:(nullable NSError *)error CustomEmptyType:(STEmptyType)emptyType;


/**
 当需要获取空白视图的点击事件时  子类重写此方法
 */
- (void)emptyDataSet:(UIScrollView *)scrollView didTapView:(UIView *)view;

@end

NS_ASSUME_NONNULL_END
