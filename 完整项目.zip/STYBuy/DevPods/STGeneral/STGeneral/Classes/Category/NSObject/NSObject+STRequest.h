//
//  NSObject+STRequest.h
//  STYBuy
//
//  Created by 高欣 on 2018/6/27.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum : NSUInteger {
    /** GET */
    STRequestMethodGET,
    /** POST */
    STRequestMethodPOST,
    
} STRequestMethod;

typedef enum : NSUInteger {
    STRequestJson,
    STRequestHttp,
} STRequestContentType;


@interface NSObject (STRequest)


/**
 请求格式
 */
@property (nonatomic,assign) STRequestContentType st_requestContentType;

/**
 链接
 */
@property (nonatomic,copy) NSString *st_requestURL;


/**
 参数
 */
@property (nonatomic,strong) NSMutableDictionary *st_parameters;


/**
 method
 */
@property (nonatomic, assign) STRequestMethod st_method;


/**
 是否需要显示加载弹窗
 */
@property (nonatomic,assign) BOOL st_needHUD;


/**
 当后台返回success = 0 时弹窗提示错误信息
 */
@property (nonatomic,assign) BOOL st_success0_showErrorInfo;

/**
 需要userid 和shopid 默认为yes
 */
@property (nonatomic,assign) BOOL st_needUserIdAndShopId;

/**
 是否只需要success = 1 的回调
 */
@property (nonatomic,assign) BOOL st_onlySuccess1;

@end
