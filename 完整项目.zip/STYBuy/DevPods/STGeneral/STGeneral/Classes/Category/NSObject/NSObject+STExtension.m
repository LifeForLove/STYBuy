//
//  NSObject+STExtension.m
//  STYBuy
//
//  Created by 高欣 on 2018/12/25.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#import "NSObject+STExtension.h"
#import <objc/runtime.h>
@implementation NSObject (STExtension)

/*
 根据拼音的字母排序  ps：排序适用于所有类型
 */
+ (NSMutableArray *)paixuWith:(NSMutableArray *)array{
    [array sortUsingComparator:^NSComparisonResult(NSString *node1, NSString *node2) {
        return [node1 compare:node2];
    }];
    return array;
}

/**
 拷贝一个模型的值 并赋值给自己
 
 @param copyModel 要拷贝的模型
 */
- (void)st_CopyModel:(NSObject *)copyModel
{
    unsigned int count = 0;
    objc_property_t *propertyList = class_copyPropertyList([self class], &count);
    for (int i = 0; i < count; i++) {
        objc_property_t proper = propertyList[i];
        const char * name = property_getName(proper);
        NSString* key = [NSString stringWithUTF8String:name];
        id value = [copyModel valueForKey:key];
        [self setValue:value forKey:key];
    }
    free(propertyList);
}


@end

@implementation NSObject (TableView)

- (UITableView *)st_TableView
{
    UITableView *st_TableView = objc_getAssociatedObject(self, @selector(st_TableView));
    if (!st_TableView)
    {
        st_TableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];

        st_TableView.delegate =self;
        st_TableView.dataSource = self;
        st_TableView.showsHorizontalScrollIndicator = NO;
        st_TableView.showsVerticalScrollIndicator = NO;
        st_TableView.backgroundColor = [UIColor groupTableViewBackgroundColor];
        st_TableView.separatorColor = [UIColor colorWithRed:238/255.0 green:238/255.0 blue:238/255.0 alpha:1];
        st_TableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);

        if (@available(iOS 11.0, *)) {
            st_TableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
            st_TableView.estimatedSectionHeaderHeight = 0;
            st_TableView.estimatedSectionFooterHeight = 0;
        } else {
        }
        objc_setAssociatedObject(self, @selector(st_TableView), st_TableView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    return st_TableView;
}

- (void)setSt_TableView:(UITableView *)st_TableView
{
    objc_setAssociatedObject(self, @selector(st_TableView), st_TableView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (UITableView *)st_GroupTableView
{
    UITableView *st_GroupTableView = objc_getAssociatedObject(self, @selector(st_GroupTableView));
    if (!st_GroupTableView)
    {
        st_GroupTableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        
        st_GroupTableView.delegate = self;
        st_GroupTableView.dataSource = self;
        st_GroupTableView.showsHorizontalScrollIndicator = NO;
        st_GroupTableView.showsVerticalScrollIndicator = NO;
        st_GroupTableView.backgroundColor = [UIColor groupTableViewBackgroundColor];
        st_GroupTableView.separatorColor = [UIColor colorWithRed:238/255.0 green:238/255.0 blue:238/255.0 alpha:1];
        st_GroupTableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
        
        if (@available(iOS 11.0, *)) {
            st_GroupTableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
            st_GroupTableView.estimatedSectionHeaderHeight = 0;
            st_GroupTableView.estimatedSectionFooterHeight = 0;
        } else {
        }
        objc_setAssociatedObject(self,@selector(st_GroupTableView) , st_GroupTableView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    return st_GroupTableView;
}

- (void)setSt_GroupTableView:(UITableView *)st_GroupTableView
{
    objc_setAssociatedObject(self, @selector(st_GroupTableView), st_GroupTableView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

@end
