//
//  NSObject+STExtension.h
//  STYBuy
//
//  Created by 高欣 on 2018/12/25.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (STExtension)

/*
 根据拼音的字母排序  ps：排序适用于所有类型
 */
+ (NSMutableArray *)paixuWith:(NSMutableArray *)array;

- (void)st_CopyModel:(NSObject *)copyModel;

@end


@interface NSObject (TableView)<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView * st_TableView;
@property (nonatomic, strong) UITableView * st_GroupTableView;

@end


NS_ASSUME_NONNULL_END
