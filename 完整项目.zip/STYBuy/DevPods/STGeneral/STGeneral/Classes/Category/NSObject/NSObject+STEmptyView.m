//
//  NSObject+STEmptyView.m
//  STYBuy
//
//  Created by 高欣 on 2019/1/12.
//  Copyright © 2019年 getElementByYou. All rights reserved.
//

#import "NSObject+STEmptyView.h"
#import <Masonry/Masonry.h>
@implementation NSObject (STEmptyView)


/**
 允许空白展位图的滚动 如果不想滚动 子类重写该方法即可
 */
- (BOOL)emptyDataSetShouldAllowScroll:(UIScrollView *)scrollView
{
    return YES;
}


/**
 返回自定义的空白占位视图
 */
- (UIView *)customViewForEmptyDataSet:(UIScrollView *)scrollView
{
    self.emptyView.frame = scrollView.bounds;
    NSLayoutConstraint *heightConstraint = [NSLayoutConstraint constraintWithItem:self.emptyView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:scrollView.mj_h];
    [self.emptyView addConstraint:heightConstraint];
    self.emptyView.backgroundColor = scrollView.backgroundColor;
    return self.emptyView;
}

/**
 当tableView中没有数据时需展示不同类型的空白占位图
 */
- (void)scrollViewConfigRequestStateForEmptyView:(UIScrollView *)scrollView error:(nullable NSError *)error CustomEmptyType:(STEmptyType)emptyType
{
    //先设置空白展位图
    scrollView.emptyDataSetSource = self;
    scrollView.emptyDataSetDelegate = self;
    
    //如果请求失败的情况
    if (error) {
        switch (error.code) {
            case NSURLErrorNotConnectedToInternet: //-1009
                self.emptyView.emptyType = STEmptyType_NoNetWork;
                break;
            case NSURLErrorTimedOut:
                self.emptyView.emptyType = STEmptyType_TimedOut;
                break;
            default:
                self.emptyView.emptyType = STEmptyType_ErrorDefault;
                break;
        }
        
    }else
    {
        //请求成功但 没有内容的情况
        if (emptyType) {
            self.emptyView.emptyType = emptyType;
        }else
        {
            self.emptyView.emptyType = STEmptyType_NoData;
        }
        
    }
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if ([scrollView isKindOfClass:[UITableView class]]) {
            UITableView * tableView = (UITableView *)scrollView;
            [tableView reloadData];
            if ([tableView.mj_header isRefreshing])[tableView.mj_header endRefreshing];
            if ([tableView.mj_footer isRefreshing])[tableView.mj_footer endRefreshing];
        }else if ([scrollView isKindOfClass:[UICollectionView class]])
        {
            UICollectionView * collectionView = (UICollectionView *)scrollView;
            [collectionView reloadData];
            if ([collectionView.mj_header isRefreshing])[collectionView.mj_header endRefreshing];
            if ([collectionView.mj_footer isRefreshing])[collectionView.mj_footer endRefreshing];
        }
    });
}

/**
 空白占位图的点击事件
 */
- (void)emptyDataSet:(UIScrollView *)scrollView didTapView:(UIView *)view{};


- (STEmptyView *)emptyView
{
    STEmptyView * emptyView = objc_getAssociatedObject(self, @selector(emptyView));
    if (!emptyView) {
        emptyView = [[STEmptyView alloc]init];
        objc_setAssociatedObject(self, @selector(emptyView) , emptyView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    return emptyView;
}

@end
