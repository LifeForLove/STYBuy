//
//  UIScrollView+STExtension.m
//  STYBuy
//
//  Created by 高欣 on 2018/12/25.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#import "UIScrollView+STExtension.h"
#import <MJRefresh/MJRefresh.h>

@implementation UIScrollView (STExtension)

@end

@implementation UIScrollView (STRefreshHeader)

- (void)st_addHeaderToRefreshWithActionHandler:(void (^)(void))actionHandler
{
    [self st_addHeaderToRefreshWithBackgroundColor:self.backgroundColor ActionHandler:actionHandler];
}

- (void)st_addHeaderToRefreshWithBackgroundColor:(UIColor *)backgroundColor ActionHandler:(void (^)(void))actionHandler
{
    if (!self.mj_header) {
        self.mj_header = [GXRefreshHeader headerWithRefreshingBlock:^{
            if (self.mj_footer) {
                self.mj_footer.state = MJRefreshStateIdle;
            }
            if (actionHandler) {
                actionHandler();
            }
        }];
        self.mj_header.backgroundColor = backgroundColor;
    }
}

- (void)st_addFooterToRefreshWithActionHandler:(void (^)(void))actionHandler
{
    if (!self.mj_footer) {
        self.mj_footer = [GXRefreshFooter footerWithRefreshingBlock:^{
            if (actionHandler) {
                actionHandler();
            }
        }];
    }
}



@end
