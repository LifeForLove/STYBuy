//
//  UIScrollView+STExtension.h
//  STYBuy
//
//  Created by 高欣 on 2018/12/25.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIScrollView (STExtension)


@end


@interface UIScrollView (STRefreshHeader)

- (void)st_addHeaderToRefreshWithActionHandler:(void (^)(void))actionHandler;
- (void)st_addHeaderToRefreshWithBackgroundColor:(UIColor *)backgroundColor ActionHandler:(void (^)(void))actionHandler;

- (void)st_addFooterToRefreshWithActionHandler:(void (^)(void))actionHandler;


@end


NS_ASSUME_NONNULL_END
