# STGeneral


#### 介绍
天易购通用UI基础组件

#### 软件架构
软件架构说明


#### 安装教程

1. xxxx
2. xxxx
3. xxxx

#### 使用说明

1. xxxx
2. xxxx
3. xxxx

#### 参与贡献

1. Fork 本仓库
2. 新建 Feat_xxx 分支
3. 提交代码
4. 新建 Pull Request


#### 码云特技

[![CI Status](https://img.shields.io/travis/LifeForLove/STGeneral.svg?style=flat)](https://travis-ci.org/LifeForLove/STGeneral)
[![Version](https://img.shields.io/cocoapods/v/STGeneral.svg?style=flat)](https://cocoapods.org/pods/STGeneral)
[![License](https://img.shields.io/cocoapods/l/STGeneral.svg?style=flat)](https://cocoapods.org/pods/STGeneral)
[![Platform](https://img.shields.io/cocoapods/p/STGeneral.svg?style=flat)](https://cocoapods.org/pods/STGeneral)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

STGeneral is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'STGeneral'
```

## Author

LifeForLove, getElementByYou@163.com

## License

STGeneral is available under the MIT license. See the LICENSE file for more info.



