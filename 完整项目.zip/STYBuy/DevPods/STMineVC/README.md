# STMineVC

[![CI Status](https://img.shields.io/travis/LifeForLove/STMineVC.svg?style=flat)](https://travis-ci.org/LifeForLove/STMineVC)
[![Version](https://img.shields.io/cocoapods/v/STMineVC.svg?style=flat)](https://cocoapods.org/pods/STMineVC)
[![License](https://img.shields.io/cocoapods/l/STMineVC.svg?style=flat)](https://cocoapods.org/pods/STMineVC)
[![Platform](https://img.shields.io/cocoapods/p/STMineVC.svg?style=flat)](https://cocoapods.org/pods/STMineVC)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

STMineVC is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'STMineVC'
```

## Author

LifeForLove, getElementByYou@163.com

## License

STMineVC is available under the MIT license. See the LICENSE file for more info.
