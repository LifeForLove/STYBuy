//
//  STMineHeadCell.h
//  STYBuy
//
//  Created by 高欣 on 2018/7/6.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#import <STSections/STSections.h>

@interface STMineHeadCell : STBaseTableViewCell

/**
 头像
 */
@property (nonatomic,strong) UIImageView *iconImg;

/**
 名称
 */
@property (nonatomic,strong) UILabel *name_lab;

/**
 头像点击事件
 */
@property (nonatomic,strong) UITapGestureRecognizer *iconTap;

@end
