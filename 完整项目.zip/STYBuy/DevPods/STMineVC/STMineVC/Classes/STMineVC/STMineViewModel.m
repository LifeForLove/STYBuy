//
//  STMineViewModel.m
//  STMineVC
//
//  Created by 高欣 on 2019/3/1.
//

#import "STMineViewModel.h"
#import "STMineHeadCell.h"
@implementation STMineViewModel

- (void)st_viewDidLoad
{
    self.viewInfoArr = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"STMineVC.bundle/myplist" ofType:@"plist"]];
    @weakify(self);
    [RACObserve(STCurrentUser, reloadData) subscribeNext:^(id x) {
        @strongify(self);
        [self.st_vmTab reloadData];
    }];
}

- (void)st_configCellTarget:(UITableViewCell *)cell IndexPath:(NSIndexPath *)indexPath
{
    if ([cell isKindOfClass:[STMineHeadCell class]]) {
        STMineHeadCell * headCell = (STMineHeadCell *)cell;
        [headCell.iconImg head_setImageWithString:STCurrentUser.logo];
        headCell.name_lab.text = STCurrentUser.nickName?:@"";
        @weakify(self);
        [[headCell.iconTap.rac_gestureSignal takeUntil:cell.rac_prepareForReuseSignal]subscribeNext:^(id x) {
            @strongify(self);
            [self iconClick];
        }];
    }else
    {
        cell.textLabel.text = self.viewInfoArr[indexPath.section][indexPath.row][@"title"];
    }
}

/**
 cell 点击事件

 @param indexPath indexPath
 */
- (void)st_configSelectIndexPath:(NSIndexPath *)indexPath
{
    NSString * nextVc = self.viewInfoArr[indexPath.section][indexPath.row][@"nextVc"];
    [UIManager showViewControllerWithName:nextVc];
}

/**
 头像点击事件
 */
- (void)iconClick
{
    if ([STCurrentUser.userState integerValue] == 0) {
        //未登录
        [STLoginVC show:^(NSInteger code) {
            if (code == 200) {
                HUD(@"登录成功")
            }
        }];
    }else
    {
        //已登录
        [UIManager showViewControllerWithName:@"STUserInfoVC"];
    }
}


@end
