//
//  STMineHeadCell.m
//  STYBuy
//
//  Created by 高欣 on 2018/7/6.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#import "STMineHeadCell.h"

@interface STMineHeadCell()

@end


@implementation STMineHeadCell

- (void)createView
{
    [self.contentView addSubview:self.iconImg];
    [self.iconImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.contentView);
        make.size.mas_equalTo(60);
        make.top.mas_equalTo(30);
    }];
    
    [self.contentView addSubview:self.name_lab];
    [self.name_lab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.iconImg);
        make.width.mas_lessThanOrEqualTo(200);
        make.top.equalTo(self.iconImg.mas_bottom).offset(15);
    }];
}

- (void)configTarget
{
    //添加手势
    self.iconTap = [[UITapGestureRecognizer alloc] init];
    [self.iconImg addGestureRecognizer:self.iconTap];
}

- (UILabel *)name_lab
{
    if (_name_lab == nil) {
        _name_lab = [UILabel labelWithColor:UIColorHex(#333333) font:Font(15) alignment:NSTextAlignmentCenter title:@""];
    }
    return _name_lab;
}

- (UIImageView *)iconImg
{
    if (_iconImg == nil) {
        _iconImg = [[UIImageView alloc]init];
        _iconImg.layer.cornerRadius = 5;
        _iconImg.layer.masksToBounds = YES;
        _iconImg.clipsToBounds = YES;
        _iconImg.userInteractionEnabled = YES;
        _iconImg.backgroundColor = [UIColor colorWithRed:arc4random_uniform(255)/255.0 green:arc4random_uniform(255)/255.0 blue:arc4random_uniform(255)/255.0 alpha:1];
    }
    return _iconImg;
}

@end
