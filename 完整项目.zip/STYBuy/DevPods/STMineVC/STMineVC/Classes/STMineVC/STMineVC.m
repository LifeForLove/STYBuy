//
//  STMineVC.m
//  Pods
//
//  Created by 高欣 on 2019/2/27.
//

#import "STMineVC.h"
#import "STMineHeadCell.h"
#import "STMineViewModel.h"
static NSString * const STMineHeadCellIdentifi = @"STMineHeadCellIdentifi";
static NSString * const STMineCellIdentifi = @"STMineCellIdentifi";
@interface STMineVC ()

@end

@implementation STMineVC

- (void)viewDidLoad {
    [super viewDidLoad];
    STMineViewModel * viewModel = [[STMineViewModel alloc]init];
    [self st_configTabelViewType:UITableViewStylePlain viewModel:viewModel];
}

- (void)st_configTableViewStyle:(UITableView *)tableView
{
    tableView.separatorColor = UIColorHex(#EEEEEE);
    [tableView registerClass:[STMineHeadCell class] forCellReuseIdentifier:STMineHeadCellIdentifi];
    [tableView registerClass:[STBaseTableViewCell class] forCellReuseIdentifier:STMineCellIdentifi];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    STMineViewModel * viewModel = (STMineViewModel *)self.viewModel;
    NSString * identi = viewModel.viewInfoArr[indexPath.section][indexPath.row][@"cell"];
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identi];
    if (cell == nil) {
        Class cla = NSClassFromString(identi);
        if ([cla isSubclassOfClass:[UITableViewCell class]]) {
            cell = [(UITableViewCell *)[cla alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identi];
            if (indexPath.section != 0) {
                cell.accessoryView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"acc_right"]];
            }
        }else
        {
            cell = [UITableViewCell new];
        }
    }
    [self.viewModel st_configCellTarget:cell IndexPath:indexPath];
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    STMineViewModel * viewModel = (STMineViewModel *)self.viewModel;
    return viewModel.viewInfoArr[section].count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    STMineViewModel * viewModel = (STMineViewModel *)self.viewModel;
    return viewModel.viewInfoArr.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    STMineViewModel * viewModel = (STMineViewModel *)self.viewModel;
    return [viewModel.viewInfoArr[indexPath.section][indexPath.row][@"rowHeight"] integerValue];
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 10;
}


@end
