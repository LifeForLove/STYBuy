//
//  STDemoModel.m
//  STMineVC
//
//  Created by 高欣 on 2019/3/7.
//

#import "STDemoModel.h"

@implementation STDemoModel

+ (void)requestWithRequestMessage:(void (^)(NSObject *, NSMutableDictionary *))requestMessage success:(void (^)(id))successBlock failure:(void (^)(NSError *))failureBlock
{
    [GXNetTools sendRequsetWithMessage:requestMessage successBlock:^(id obj) {
        STDemoModel * model = [STDemoModel mj_objectWithKeyValues:obj];
        successBlock(model);
    } errorBlock:^(NSError *error) {
        failureBlock(error);
    }];
}

+ (NSDictionary *)mj_objectClassInArray
{
    return @{@"list" : @"STDemoListModel",
             @"info" : @"STDemoInfoModel"
             };
}


@end

@implementation STDemoInfoModel

@end

@implementation STDemoListModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{
             @"ID" : @"id",
             
             @"smallPicture" : @"image0",
             
             @"middlePicture" : @"image2",
             
             @"largePicture" : @"image1",
             
             @"voiceUrl" : @"voiceuri",
             
             @"videoUrl" : @"videouri",
             
             @"gif" : @"is_gif",
             
             @"topCmts" : @"top_cmt",
             
             };
}
@end
