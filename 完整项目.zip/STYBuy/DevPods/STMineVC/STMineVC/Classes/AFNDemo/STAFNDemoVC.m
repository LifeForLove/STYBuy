//
//  STAFNDemoVC.m
//  STMineVC
//
//  Created by 高欣 on 2019/3/7.
//

#import "STAFNDemoVC.h"
#import "STDemoViewModel.h"
#import "STDemoModel.h"
@interface STAFNDemoVC ()

@property (nonatomic,weak) STDemoViewModel *demoViewModel;

@end

@implementation STAFNDemoVC

- (void)viewDidLoad {
    [super viewDidLoad];
    STDemoViewModel * viewModel = [[STDemoViewModel alloc]init];
    self.demoViewModel = viewModel;
    [self st_configTabelViewType:UITableViewStylePlain viewModel:viewModel];
}

- (void)st_configTableViewStyle:(UITableView *)tableView
{
    tableView.separatorColor = UIColorHex(#EEEEEE);
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    STBaseTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[STBaseTableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
    }
    [self.demoViewModel st_configCellTarget:cell IndexPath:indexPath];
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.demoViewModel.infoArr.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}


@end
