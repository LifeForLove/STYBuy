//
//  STDemoViewModel.h
//  STMineVC
//
//  Created by 高欣 on 2019/3/7.
//

#import "STBaseTableViewModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface STDemoViewModel : STBaseTableViewModel
@property (nonatomic,strong) NSMutableArray *infoArr;
@end

NS_ASSUME_NONNULL_END
