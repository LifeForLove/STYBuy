//
//  STDemoViewModel.m
//  STMineVC
//
//  Created by 高欣 on 2019/3/7.
//

#import "STDemoViewModel.h"
#import "STDemoModel.h"
@implementation STDemoViewModel

- (void)st_viewDidLoad
{
    //上拉加载
    @weakify(self);
    [self.st_vmTab st_addFooterToRefreshWithActionHandler:^{
        @strongify(self);
        [self loadDataWithType:2];
    }];
    
    //下拉刷新
    [self.st_vmTab st_addHeaderToRefreshWithActionHandler:^{
        @strongify(self);
        [self loadDataWithType:1];
    }];
    
    [self loadDataWithType:1];
}

/**
 请求数据
 
 @param type 1 下拉 2 上拉
 */
- (void)loadDataWithType:(NSInteger)type
{
    @weakify(self);
    [STDemoModel requestWithRequestMessage:^(NSObject *message, NSMutableDictionary *dict) {
        message.st_requestURL = REQUESTURL(@"api/api_open.php");
        message.st_method = STRequestMethodGET;
        message.st_needHUD = YES;
        dict[@"a"] = @"list";
        dict[@"c"] = @"data";
        dict[@"per"] = @PageCount;
        dict[@"type"] = @1;
        dict[@"maxtime"] = @([[NSDate date]timeIntervalSince1970]);
        //分页计算 type == 1 ? @1 : @((1 + self.infoArr.count / PageCount) + ( self.infoArr.count % PageCount == 0 ? 0 : 1));
    } success:^(STDemoModel *model) {
        @strongify(self);
        if (type == 1) {
            self.infoArr = model.list;
        }else
        {
            [self.infoArr addObjectsFromArray:model.list];
            //暂无数据
            if (!model.list || model.list.count == 0) self.st_vmTab.mj_footer.state = MJRefreshStateNoMoreData;
        }
        [self scrollViewConfigRequestStateForEmptyView:self.st_vmTab error:0 CustomEmptyType:0];
    } failure:^(NSError *error) {
        @strongify(self);
        [self scrollViewConfigRequestStateForEmptyView:self.st_vmTab error:error CustomEmptyType:0];
    }];
}

- (void)st_configCellTarget:(UITableViewCell *)cell IndexPath:(NSIndexPath *)indexPath
{
    STDemoListModel * listModel = self.infoArr[indexPath.row];
    cell.textLabel.text = listModel.name;
}


@end
