//
//  ELBrowserVC.m
//  STMineVC
//
//  Created by 高欣 on 2019/3/6.
//

#import "ELBrowserVC.h"
#import <ELBrowser/ELBrowser.h>
@interface ElTableViewCell :STBaseTableViewCell

@property (nonatomic,strong) ELBrowser * browser;


/**
 图片链接数组
 */
@property (nonatomic,strong) NSArray *picArr;


@end


@implementation ElTableViewCell

- (void)createView
{
    [self.contentView addSubview:self.browser];
    [self.browser mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView).offset(20);
        make.width.mas_equalTo(200);
        make.centerX.equalTo(self.contentView);
        make.bottom.equalTo(self.contentView).offset(-20);
    }];
}

- (void)setPicArr:(NSArray *)picArr
{
    _picArr = picArr;
    
    NSMutableArray * thumbnailImageUrls = [NSMutableArray array];
    NSMutableArray * originalImageUrls = [NSMutableArray array];
    for (NSDictionary * dic in picArr) {
        [thumbnailImageUrls addObject:dic[@"timg"]];
        [originalImageUrls addObject:dic[@"oimg"]];
    }
    
    ELBrowserConfig * config = [[ELBrowserConfig alloc]init];
    config.originalUrls = originalImageUrls;//大图
    config.smallUrls = thumbnailImageUrls;//缩略图 (必传)
    config.width = 200;//宽度 (必传)
    //    config.progressPathWidth = 1;
    //    config.progressPathFillColor = [UIColor redColor];
    //    config.progressBackgroundColor = [UIColor whiteColor];
    [self.browser showELBrowserWithConfig:config];
    
}


- (ELBrowser *)browser
{
    if (_browser == nil) {
        _browser = [[ELBrowser alloc]init];
    }
    return _browser;
}


@end

@interface ELBrowserVC ()
@property (nonatomic,strong) NSArray *infoArr;
@end

@implementation ELBrowserVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"仿朋友圈图片浏览器";
    self.infoArr = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle]pathForResource:@"STMineVC.bundle/ImageURLPlist.plist" ofType:nil]];
    [self st_configTabelViewType:UITableViewStylePlain viewModel:nil];
}

- (void)st_configTableViewStyle:(UITableView *)tableView
{
    tableView.estimatedRowHeight = 44.f;
    [tableView registerClass:[ElTableViewCell class] forCellReuseIdentifier:@"cell"];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.infoArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ElTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.picArr = self.infoArr[indexPath.row];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [tableView fd_heightForCellWithIdentifier:@"cell" configuration:^(ElTableViewCell * cell) {
        cell.picArr = self.infoArr[indexPath.row];
    }];
}

@end
