//
//  STMyGithubVC.h
//  STMineVC
//
//  Created by 高欣 on 2019/3/6.
//

#import <STSections.h>

NS_ASSUME_NONNULL_BEGIN

@interface STMyGithubVC : STBaseTableViewController

@end

NS_ASSUME_NONNULL_END
