//
//  STMyGithubVC.m
//  STMineVC
//
//  Created by 高欣 on 2019/3/6.
//

#import "STMyGithubVC.h"

@interface STMyGithubVC ()

@property (nonatomic,strong) NSArray *titleArr;

@end

@implementation STMyGithubVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"个人作品";
    self.titleArr = @[@"仿今日头条点赞表情喷射效果",@"仿朋友圈图片浏览器",@"仿今日头条标签选"];
    [self st_configTabelViewType:UITableViewStylePlain viewModel:nil];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    STBaseTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[STBaseTableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
        cell.accessoryView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"acc_right"]];
    }
    cell.textLabel.text = self.titleArr[indexPath.row];
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.titleArr.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row) {
        case 0:
            [UIManager showViewControllerWithName:@"STUpvoteVC"];
            break;
        case 1:
            [UIManager showViewControllerWithName:@"ELBrowserVC"];
            break;
        case 2:
            [UIManager showViewControllerWithName:@"STMyLabelsVC"];
            break;
        default:
            break;
    }
    
    
}


@end
