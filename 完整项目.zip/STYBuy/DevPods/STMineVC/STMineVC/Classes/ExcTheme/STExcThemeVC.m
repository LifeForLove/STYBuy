//
//  STExcThemeVC.m
//  STMineVC
//
//  Created by 高欣 on 2019/3/4.
//

#import "STExcThemeVC.h"

static NSString * const STExcThemeCellIdentifi = @"STExcThemeCellIdentifi";


@interface STExcThemeVC ()

@property (nonatomic,strong) NSArray *titleArr;

@end

@implementation STExcThemeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"更改主题";
    self.titleArr = @[@"网易红",@"微信绿",@"支付宝蓝"];
    [self st_configTabelViewType:UITableViewStylePlain viewModel:nil];
}

- (void)st_configTableViewStyle:(UITableView *)tableView
{
    tableView.separatorColor = UIColorHex(#EEEEEE);
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    STBaseTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:STExcThemeCellIdentifi];
    if (cell == nil) {
        cell = [[STBaseTableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:STExcThemeCellIdentifi];
        cell.accessoryView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 40, 40)];
    }
    cell.textLabel.text = self.titleArr[indexPath.row];
    switch (indexPath.row) {
        case 0:
            cell.accessoryView.backgroundColor = UIColorHex(#CB2B29);
            break;
        case 1:
            cell.accessoryView.backgroundColor = UIColorHex(#98D55D);
            break;
        case 2:
            cell.accessoryView.backgroundColor = UIColorHex(#4987F7);
            break;
            
        default:
            break;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row) {
        case 0:
            //网易红
            STTheme.mainColor =  UIColorHex(#CB2B29);
            break;
        case 1:
            //微信绿
            STTheme.mainColor =  UIColorHex(#98D55D);
            break;
        case 2:
            //支付宝蓝
            STTheme.mainColor =  UIColorHex(#4987F7);
            break;
            
        default:
            break;
    }
    [STTheme configTheme];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.titleArr.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

@end
