//
//  STUpvoteVC.m
//  STMineVC
//
//  Created by 高欣 on 2019/3/6.
//

#import "STUpvoteVC.h"
#import "GXUpvoteButton.h"
@interface STUpvoteVC ()

@end

@implementation STUpvoteVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"仿今日头条点赞表情喷射";
    GXUpvoteButton * upvoteButton = [GXUpvoteButton buttonWithType:UIButtonTypeCustom];
    [self.view addSubview:upvoteButton];
    upvoteButton.frame = CGRectMake(0, 0, 50, 50);
    upvoteButton.center = self.view.center;
}

@end
