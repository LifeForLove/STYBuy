//
//  STUserInfoVC.m
//  STMineVC
//
//  Created by 高欣 on 2019/3/3.
//

#import "STUserInfoVC.h"

@interface STUserInfoVC ()

@property (nonatomic,strong) NSArray *titleArr;

@end

@implementation STUserInfoVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"基本信息";
    self.titleArr = @[@{@"title":@"头像",@"value":@"logo"},
                      @{@"title":@"昵称",@"value":@"nickName"},
                      @{@"title":@"手机号",@"value":@"phone"}];
    [self st_configTabelViewType:UITableViewStylePlain viewModel:nil];
}

- (void)st_configTableViewStyle:(UITableView *)tableView
{
    tableView.footType = FootType_button;
    tableView.footTitle = @"退出登录";
    [[tableView.footBtn rac_signalForControlEvents:UIControlEventTouchUpInside]subscribeNext:^(id x) {
        [STUserManager loginOut:^{
            HUD(@"退出成功")
        } fail:^{
        }];
    }];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    STBaseTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[STBaseTableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
    }
    NSString * title = self.titleArr[indexPath.row][@"title"];
    NSString * vaule = self.titleArr[indexPath.row][@"value"];
    NSString * content = vaule ? [STCurrentUser valueForKey:vaule] : @"";
    cell.textLabel.text = title;
    if ([title isEqualToString:@"头像"]) {
        if (!cell.accessoryView) cell.accessoryView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 40, 40)];
        UIImageView * headImg = (UIImageView *)cell.accessoryView;
        [headImg head_setImageWithString:content];
    }else
    {
        cell.detailTextLabel.text = content;
    }
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.titleArr.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return indexPath.row == 0 ? 60 : 44;
}



@end
