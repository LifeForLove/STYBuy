//
//  STCoobjcDemoViewModel.h
//  STMineVC
//
//  Created by 高欣 on 2019/3/7.
//

#import <STSections.h>

NS_ASSUME_NONNULL_BEGIN

@interface STCoobjcDemoViewModel : STBaseTableViewModel

@property (nonatomic,strong) NSMutableArray *infoArr;

@end

NS_ASSUME_NONNULL_END
