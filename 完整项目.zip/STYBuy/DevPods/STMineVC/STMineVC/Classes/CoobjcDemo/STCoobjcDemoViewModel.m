//
//  STCoobjcDemoViewModel.m
//  STMineVC
//
//  Created by 高欣 on 2019/3/7.
//

#import "STCoobjcDemoViewModel.h"
#import "STDemoModel.h"
#import "STNetTools.h"
@implementation STCoobjcDemoViewModel

- (void)st_viewDidLoad
{
    //上拉加载
    @weakify(self);
    [self.st_vmTab st_addFooterToRefreshWithActionHandler:^{
        @strongify(self);
        [self loadDataWithType:2];
    }];
    
    //下拉刷新
    [self.st_vmTab st_addHeaderToRefreshWithActionHandler:^{
        @strongify(self);
        [self loadDataWithType:1];
    }];
    
    [self loadDataWithType:1];
}

- (void)st_configCellTarget:(UITableViewCell *)cell IndexPath:(NSIndexPath *)indexPath
{
    STDemoListModel * listModel = self.infoArr[indexPath.row];
    cell.textLabel.text = listModel.name;
}


//**********************************************************

- (void)demo3
{
    co_launch(^{
        id result = await([self co_fetchSomethingAsynchronous]);
        NSError *error = co_getError();
        if (error) {
            NSLog(@"%@",error);
        }else
        {
            NSLog(@"%@",result);
        }
    });
}


// make a async operation
- (COPromise<id> *)co_fetchSomethingAsynchronous {
    return [COPromise promise:^(COPromiseFullfill  _Nonnull fullfill, COPromiseReject  _Nonnull reject) {
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            NSError * error = [NSError errorWithDomain:@"服务器爆炸" code:404 userInfo:@{NSLocalizedDescriptionKey : @"Serveres Explosion"}];
            id ret = nil;
            
            if (error) {
                reject(error);
            } else {
                fullfill(ret);
            }
        });
    }];
    
}


//**********************************************************

/**
 COChan 按顺序请求
 */
- (void)demo2
{
    co_launch(^{
        id result = await([self requsetUserInfo]);
        id fance = await([self requestUserFance]);
        NSLog(@"%@\n%@",result,fance);
    });
}

- (COChan *)requsetUserInfo
{
    COChan *chan = [COChan chan];
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        // fetch result operations
        [NSThread sleepForTimeInterval:5];
        [chan send_nonblock:@{@"name":@"gx",@"sex":@"0"}];
    });
    return chan;
}

- (COChan *)requestUserFance
{
    COChan *chan = [COChan chan];
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        // fetch result operations
        [chan send_nonblock:@{@"money":@"100"}];
    });
    return chan;
}

/**
 请求数据
 
 @param type 1 下拉 2 上拉
 */
- (void)loadDataWithType:(NSInteger)type
{
    co_launch(^{
        NSLog(@"11111111");
        id obj = [STNetTools st_requestWithMessage:^(NSObject * _Nonnull message, NSMutableDictionary * _Nonnull dict) {
            message.st_requestURL = REQUESTURL(@"api/api_open.php");
            message.st_method = STRequestMethodGET;
            message.st_needHUD = YES;
            dict[@"a"] = @"list";
            dict[@"c"] = @"data";
            dict[@"per"] = @PageCount;
            dict[@"type"] = @1;
            dict[@"maxtime"] = @([[NSDate date]timeIntervalSince1970]);
        }];
        
        NSError *error = co_getError();
        
        if (error) {
            [self scrollViewConfigRequestStateForEmptyView:self.st_vmTab error:error CustomEmptyType:0];
        }else if ([obj isKindOfClass:[NSDictionary class]]) {
            STDemoModel * model = [STDemoModel mj_objectWithKeyValues:obj];
            if (type == 1) {
                self.infoArr = model.list;
            }else
            {
                [self.infoArr addObjectsFromArray:model.list];
                //暂无数据
                if (!model.list || model.list.count == 0) self.st_vmTab.mj_footer.state = MJRefreshStateNoMoreData;
            }
            [self scrollViewConfigRequestStateForEmptyView:self.st_vmTab error:0 CustomEmptyType:0];
        }
    });
}


@end
