//
//  STNetTools.h
//  STMineVC
//
//  Created by 高欣 on 2019/3/7.
//

#import <STSections.h>

NS_ASSUME_NONNULL_BEGIN

@interface STNetTools : NSObject
+ (instancetype)sharedInstance;

+ (id)st_requestWithMessage:(void (^) (NSObject *message,NSMutableDictionary * dict))requestMessage CO_ASYNC;

@end

NS_ASSUME_NONNULL_END
