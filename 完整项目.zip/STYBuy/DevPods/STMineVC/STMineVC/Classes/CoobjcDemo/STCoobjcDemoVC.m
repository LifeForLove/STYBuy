//
//  STCoobjcDemoVC.m
//  STMineVC
//
//  Created by 高欣 on 2019/3/7.
//

#import "STCoobjcDemoVC.h"
#import "STCoobjcDemoViewModel.h"
@interface STCoobjcDemoVC ()

@property (nonatomic,weak) STCoobjcDemoViewModel *coobjcViewModel;

@end

@implementation STCoobjcDemoVC

- (void)viewDidLoad {
    [super viewDidLoad];
    STCoobjcDemoViewModel * viewModel = [[STCoobjcDemoViewModel alloc]init];
    self.coobjcViewModel = viewModel;
    [self st_configTabelViewType:UITableViewStylePlain viewModel:viewModel];
}

- (void)st_configTableViewStyle:(UITableView *)tableView
{
    tableView.separatorColor = UIColorHex(#EEEEEE);
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    STBaseTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[STBaseTableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
    }
    [self.coobjcViewModel st_configCellTarget:cell IndexPath:indexPath];
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.coobjcViewModel.infoArr.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44;
}

@end
