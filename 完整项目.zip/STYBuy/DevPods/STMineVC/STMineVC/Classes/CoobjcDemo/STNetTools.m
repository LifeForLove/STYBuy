//
//  STNetTools.m
//  STMineVC
//
//  Created by 高欣 on 2019/3/7.
//

#import "STNetTools.h"
#import <CommonCrypto/CommonDigest.h>

@interface STNetTools ()

//@property (nonatomic, strong) dispatch_queue_t jsonQueue;
//@property (nonatomic, strong) dispatch_queue_t networkQueue;
//@property (nonatomic, strong) dispatch_queue_t cacheQueue;
//@property (nonatomic, strong) dispatch_queue_t imageQueue;
@property (nonatomic, strong) dispatch_queue_t requestQueue;
@property (nonatomic, strong) COActor *requestActor;
//@property (nonatomic, strong) COActor *networkActor;
//@property (nonatomic, strong) COActor *jsonActor;
//@property (nonatomic, strong) COActor *imageActor;
//@property (nonatomic, strong) COActor *cacheActor;
//@property (nonatomic, strong) NSString *cachePath;

@end

@implementation STNetTools

+ (instancetype)sharedInstance{
    static STNetTools *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[STNetTools alloc] init];
    });
    return instance;
}

- (COPromise *)requestDataWithMessage:(NSObject *)message
{
    return  [COPromise promise:^(COPromiseFullfill  _Nonnull fullfill, COPromiseReject  _Nonnull reject) {
        [GXNetTools requsetWithMessage:message successBlock:^(id obj) {
            fullfill(obj);
        } errorBlock:^(NSError *error) {
            reject(error);
        }];
    } onQueue:_requestQueue];
}


- (instancetype)init{
    self = [super init];
    if (self) {
        
        _requestQueue = dispatch_queue_create("com.coobjc.request", NULL);
        
        _requestActor = co_actor_onqueue(_requestQueue, ^(COActorChan * _Nonnull channel) {
            for (COActorMessage *message in channel) {
                NSObject *obj = [message type];
                if (obj) {
                    message.complete(await([self requestDataWithMessage:obj]));
                }
                else{
                    message.complete(nil);
                }
            }
        });

    }
    return self;
}


+ (id)st_requestWithMessage:(void (^)(NSObject * _Nonnull , NSMutableDictionary * _Nonnull ))requestMessage CO_ASYNC
{
    SURE_ASYNC
    NSObject * message = [[NSObject alloc]init];
    //默认请求格式
    message.st_requestContentType = STRequestHttp;
    // 默认使用post 请求
    message.st_method = STRequestMethodPOST;
    // 默认当后台返回success = 0 时 提示 错误信息
    message.st_success0_showErrorInfo = NO;
    // 默认上传ueseId 和 shopId
    //        message.st_needUserIdAndShopId = YES;
    message.st_parameters = [NSMutableDictionary dictionary];
    requestMessage(message,message.st_parameters);
    
    return await([[STNetTools sharedInstance].requestActor sendMessage:message]);
}

@end
