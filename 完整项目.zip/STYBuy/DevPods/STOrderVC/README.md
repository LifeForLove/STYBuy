# STOrderVC

[![CI Status](https://img.shields.io/travis/LifeForLove/STOrderVC.svg?style=flat)](https://travis-ci.org/LifeForLove/STOrderVC)
[![Version](https://img.shields.io/cocoapods/v/STOrderVC.svg?style=flat)](https://cocoapods.org/pods/STOrderVC)
[![License](https://img.shields.io/cocoapods/l/STOrderVC.svg?style=flat)](https://cocoapods.org/pods/STOrderVC)
[![Platform](https://img.shields.io/cocoapods/p/STOrderVC.svg?style=flat)](https://cocoapods.org/pods/STOrderVC)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

STOrderVC is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'STOrderVC'
```

## Author

LifeForLove, getElementByYou@163.com

## License

STOrderVC is available under the MIT license. See the LICENSE file for more info.
