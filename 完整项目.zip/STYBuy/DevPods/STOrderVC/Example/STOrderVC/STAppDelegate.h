//
//  STAppDelegate.h
//  STOrderVC
//
//  Created by LifeForLove on 02/27/2019.
//  Copyright (c) 2019 LifeForLove. All rights reserved.
//

@import UIKit;

@interface STAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
