//
//  STOrderPayVC.m
//  STOrderVC
//
//  Created by 高欣 on 2019/3/2.
//

#import "STOrderPayVC.h"

@interface STOrderPayVC ()

@property (nonatomic,strong) UILabel *content_lab;

@end

@implementation STOrderPayVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"订单支付";
    [self.view addSubview:self.content_lab];
    [self.content_lab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view).offset(30);
        make.right.equalTo(self.view).offset(-30);
        make.centerY.equalTo(self.view);
    }];
    
    self.content_lab.text = [NSString stringWithFormat:@"当前商品id = %@\n\n当前商品名称 = %@",self.foodId,self.name];
}

- (UILabel *)content_lab
{
    if (_content_lab == nil) {
        _content_lab = [UILabel labelWithColor:UIColorHex(#333333) font:Font(15) alignment:NSTextAlignmentCenter title:@"" numberOfLines:0];
    }
    return _content_lab;
}


@end
