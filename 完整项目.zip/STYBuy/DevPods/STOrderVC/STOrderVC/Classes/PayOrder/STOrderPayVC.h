//
//  STOrderPayVC.h
//  STOrderVC
//
//  Created by 高欣 on 2019/3/2.
//

#import <STSections/STSections.h>

NS_ASSUME_NONNULL_BEGIN

@interface STOrderPayVC : STBaseVC

/**
 商品id
 */
@property (nonatomic,copy) NSString *foodId;

/**
 商品名称
 */
@property (nonatomic,copy) NSString *name;

@end

NS_ASSUME_NONNULL_END
