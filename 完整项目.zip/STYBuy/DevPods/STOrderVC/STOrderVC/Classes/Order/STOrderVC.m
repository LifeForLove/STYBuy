//
//  STOrderVC.m
//  STOrderVC
//
//  Created by 高欣 on 2019/2/27.
//

#import "STOrderVC.h"

@interface STOrderVC ()

@end

@implementation STOrderVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self st_configTabelViewType:UITableViewStylePlain viewModel:nil];
    
    //加载数据
    [self loadDataWithType:1];
}

- (void)loadDataWithType:(NSInteger)type
{
    [self scrollViewConfigRequestStateForEmptyView:self.tableView error:nil CustomEmptyType:STEmptyType_NoOrder];
}

- (void)st_configTableViewStyle:(UITableView *)tableView
{
    tableView.frame = CGRectMake(0, 0, kScreenWidth, kScreenHeight - SafeAreaTabbarHeight - 1);
    tableView.separatorColor = UIColorHex(#EEEEEE);
    [tableView registerClass:[STBaseTableViewCell class] forCellReuseIdentifier:@"cell"];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    STBaseTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    return  cell;
}


@end
