# STSections

[![CI Status](https://img.shields.io/travis/LifeForLove/STSections.svg?style=flat)](https://travis-ci.org/LifeForLove/STSections)
[![Version](https://img.shields.io/cocoapods/v/STSections.svg?style=flat)](https://cocoapods.org/pods/STSections)
[![License](https://img.shields.io/cocoapods/l/STSections.svg?style=flat)](https://cocoapods.org/pods/STSections)
[![Platform](https://img.shields.io/cocoapods/p/STSections.svg?style=flat)](https://cocoapods.org/pods/STSections)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

STSections is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'STSections'
```

## Author

LifeForLove, getElementByYou@163.com

## License

STSections is available under the MIT license. See the LICENSE file for more info.
