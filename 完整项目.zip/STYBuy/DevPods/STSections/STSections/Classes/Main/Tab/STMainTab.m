//
//  STMainTab.m
//  STYBuy
//
//  Created by 高欣 on 2018/5/12.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#import "STMainTab.h"


@interface STMainTab ()<UITabBarControllerDelegate>


@end

@implementation STMainTab

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.delegate = self;
    
    //添加阴影效果
    self.tabBar.layer.shadowColor = [UIColor lightGrayColor].CGColor;
    self.tabBar.layer.shadowOffset = CGSizeMake(0, -5);
    self.tabBar.layer.shadowOpacity = 0.3;
}

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController {
    tabBarController.navigationItem.title = viewController.navigationItem.title;
}

@end
