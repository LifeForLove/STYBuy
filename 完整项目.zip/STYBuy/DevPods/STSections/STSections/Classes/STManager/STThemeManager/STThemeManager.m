//
//  STThemeManager.m
//  STYBuy
//
//  Created by 高欣 on 2019/1/15.
//  Copyright © 2019年 getElementByYou. All rights reserved.
//

NSString *const STSelectedThemeClassName = @"STSelectedThemeClassName";


#import "STThemeManager.h"

@implementation STThemeManager

+ (instancetype)sharedInstance {
    static dispatch_once_t onceToken;
    static STThemeManager *instance = nil;
    dispatch_once(&onceToken,^{
        instance = [[STThemeManager alloc] init];
    });
    return instance;
}

- (void)configTheme
{
    //tabbar 透明度
    [[UITabBar appearance] setTranslucent:NO];
    //tabbar 去掉顶部的线
    [[UITabBar appearance] setShadowImage:[UIImage new]];
    [[UITabBar appearance] setBackgroundImage:[[UIImage alloc]init]];
    //tabbar 背景颜色
    [[UITabBar appearance] setBackgroundColor:UIColorHex(#FFFFFF)];
    
    //tabbar 选中颜色
    [[STAppManager manager].mainTab.tabBar setTintColor:self.mainColor];
    
    //tabbar 文字颜色
    NSMutableDictionary<NSString *, id> *text_noraml_attributes = [[NSMutableDictionary alloc] initWithDictionary:[[UITabBarItem appearance] titleTextAttributesForState:UIControlStateSelected]];
    text_noraml_attributes[NSForegroundColorAttributeName] = self.mainColor;
    [[UITabBarItem appearance] setTitleTextAttributes:text_noraml_attributes forState:UIControlStateSelected];
    
    NSMutableDictionary<NSString *, id> *text_select_attributes = [[NSMutableDictionary alloc] initWithDictionary:[[UITabBarItem appearance] titleTextAttributesForState:UIControlStateNormal]];
    text_select_attributes[NSForegroundColorAttributeName] = UIColorHex(#666666);
    [[UITabBarItem appearance] setTitleTextAttributes:text_select_attributes forState:UIControlStateNormal];
    
    //设置导航条样式
    NSMutableDictionary *att = [NSMutableDictionary dictionary];
    att[NSFontAttributeName] = [UIFont fontWithName:@"PingFangSC-Regular" size:18];
    att[NSForegroundColorAttributeName] = self.mainPairColor;
    //设置标题样式
    [[STAppManager manager].rootNavController.navigationBar setTitleTextAttributes:att];
    
    //去掉顶部黑线
    [[UINavigationBar appearance] setShadowImage:[UIImage new]];
    
    //导航栏透明度
    [[UINavigationBar appearance] setTranslucent:NO];
    
    //nav 文字颜色
    [[STAppManager manager].rootNavController.navigationBar setTintColor:self.mainPairColor];
    //导航栏背景颜色
    [[STAppManager manager].rootNavController.navigationBar setBackgroundImage:[UIImage createImageWithColor:self.mainColor] forBarMetrics:UIBarMetricsDefault];
}

- (UIColor *)mainColor
{
    if (_mainColor == nil) {
        _mainColor = UIColorHex(#CB2B29);
    }
    return _mainColor;
}

- (UIColor *)mainPairColor
{
    if (_mainPairColor == nil) {
        _mainPairColor = [UIColor whiteColor];
    }
    return _mainPairColor;
}

- (UIColor *)textTitleColor
{
    if (_textTitleColor == nil) {
        _textTitleColor = UIColorHex(#333333);
    }
    return _textTitleColor;
}

- (UIColor *)textDetailColor
{
    if (_textDetailColor == nil) {
        _textDetailColor = UIColorHex(#666666);
    }
    return _textDetailColor;
}

- (UIColor *)textThirdColor
{
    if (_textThirdColor == nil) {
        _textThirdColor = UIColorHex(#999999);
    }
    return _textThirdColor;
}





@end
