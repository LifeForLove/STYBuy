//
//  STThemeManager.h
//  STYBuy
//
//  Created by 高欣 on 2019/1/15.
//  Copyright © 2019年 getElementByYou. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#define STTheme [STThemeManager sharedInstance]

@interface STThemeManager : NSObject

/**
 主题色
 */
@property (nonatomic,strong) UIColor *mainColor;

/**
 与主题色搭配的颜色
 */
@property (nonatomic,strong) UIColor *mainPairColor;

/**
 文字标题颜色
 */
@property (nonatomic,strong) UIColor *textTitleColor;

/**
 文字副标题颜色
 */
@property (nonatomic,strong) UIColor *textDetailColor;

/**
 子标题文字颜色
 */
@property (nonatomic,strong) UIColor *textThirdColor;


+ (instancetype)sharedInstance;

- (void)configTheme;

@end

NS_ASSUME_NONNULL_END
