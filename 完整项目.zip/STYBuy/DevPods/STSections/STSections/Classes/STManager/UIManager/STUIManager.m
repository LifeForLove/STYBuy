//
//  STUIManager.m
//  STSections
//
//  Created by 高欣 on 2019/2/24.
//

#import "STUIManager.h"

@interface STUIManager ()

@property (nonatomic,strong) UINavigationController *navigationController;
//@property (nonatomic, strong) NSTimer *popDelayTimer;
//@property (nonatomic, strong) UINavigationController *popDelayNav;
@property (nonatomic,strong) UINavigationController *presentContainerNav;
@end

@implementation STUIManager

+ (instancetype)manager
{
    static STUIManager * obj;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        obj = [[STUIManager alloc]init];
    });
    return obj;
}

- (void)registerNavigationController:(UINavigationController *)navigationController
{
    self.navigationController = navigationController;
}

#pragma mark - push 视图控制器

///**
// 处理可能存在的delay pop
//
// @param ignore 指定是忽略还是执行存在的delay pop
// */
//- (void)delayPopIgnore:(BOOL)ignore {
//    if (self.popDelayTimer) {
//        [self.popDelayTimer invalidate];
//        self.popDelayTimer = nil;
//
//        if (!ignore && self.popDelayNav == [self currentNavigationController]) {
//            NSMutableArray *arrView = [NSMutableArray arrayWithArray:self.popDelayNav.viewControllers];
//            [arrView removeLastObject];
//            [self.popDelayNav setViewControllers:arrView animated:NO];
//        }
//        self.popDelayNav = nil;
//    }
//}

// push视图控制器，根据类名
- (void)showViewControllerWithName:(NSString *)name
{
    [self showViewControllerWithName:name param:nil];
}

// push视图控制器，根据类名
- (void)showViewControllerWithName:(NSString *)name
                             param:(NSDictionary *)param
{
    [self showViewControllerWithName:name param:param animated:YES];
}

// push视图控制器，根据类名
- (void)showViewControllerWithName:(NSString *)name
                             param:(NSDictionary *)param
                          animated:(BOOL)animated
{
    Class cls = NSClassFromString(name);
    [self showViewControllerWithClass:cls param:param animated:animated];
}

// push视图控制器，根据class
- (void)showViewControllerWithClass:(Class)cls
{
    [self showViewControllerWithClass:cls param:nil];
}

// push视图控制器，根据class
- (void)showViewControllerWithClass:(Class)cls
                              param:(NSDictionary *)param
{
    [self showViewControllerWithClass:cls param:param animated:YES];
}

// push视图控制器，根据class
- (void)showViewControllerWithClass:(Class)cls
                              param:(NSDictionary *)param
                           animated:(BOOL)animated
{
    UIViewController *viewController = [self viewControllerWithClass:cls];
    [self showViewController:viewController param:param animated:animated];
}

// push视图控制器
- (void)showViewController:(UIViewController *)viewController
{
    [self showViewController:viewController param:nil];
}

// push视图控制器
- (void)showViewController:(UIViewController *)viewController
                     param:(NSDictionary *)param
{
    [self showViewController:viewController param:param animated:YES];
}

// push视图控制器
- (void)showViewController:(UIViewController *)viewController
                     param:(NSDictionary *)param
                  animated:(BOOL)animated
{
    if (!viewController) {
        return;
    }
//    [self delayPopIgnore:NO];
    [self setupViewController:viewController param:param];
    [[self currentNavigationController] pushViewController:viewController animated:animated];
}



#pragma mark - pop视图控制器

// pop当前视图控制器
- (UIViewController *)popViewController
{
    return [self popViewController:YES];
}

// pop当前视图控制器
- (UIViewController *)popViewController:(BOOL)animated
{
//    [self delayPopIgnore:NO];
    UIViewController *viewController = [[self currentNavigationController] popViewControllerAnimated:animated];
    return viewController;
}

//- (void)popViewControllerAnimatedIfCan {
//    [self delayPopIgnore:NO];
//    self.popDelayNav = [self currentNavigationController];
//    self.popDelayTimer = [NSTimer scheduledTimerWithTimeInterval:0.3 target:self selector:@selector(popIfCanTimerAction) userInfo:nil repeats:NO];
//}

//- (void)popIfCanTimerAction {
//    if (self.popDelayNav == [self currentNavigationController]) {
//        [self.popDelayNav popViewControllerAnimated:YES];
//        self.popDelayTimer = nil;
//        self.popDelayNav = nil;
//    }
//}

// pop当前导航栏栈中指定视图控制器，根据class
- (UIViewController *)popToViewController:(Class)cls
{
    return [self popToViewController:cls animated:YES];
}

// pop栈队列中指定视图
- (UIViewController *)popToViewController:(Class)cls
                                 animated:(BOOL)animated
{
    UIViewController *targetViewContrller = nil;
    for (UIViewController *viewController in [self currentNavigationController].viewControllers)
    {
        if ([viewController isKindOfClass:cls]) {
            targetViewContrller = viewController;
//            [self delayPopIgnore:YES];
            [[self currentNavigationController] popToViewController:viewController animated:animated];
            break;
        }
    }
    return targetViewContrller;
}

// pop到栈底部视图
- (void)popToRoot {
//    [self delayPopIgnore:YES];
    UINavigationController *nav = [self currentNavigationController];
    [nav popToRootViewControllerAnimated:NO];
}

// pop到栈底部视图
- (void)popToRootViewController:(NSInteger)index
{
    [self popToRootViewController:index animated:NO];
}

// pop到栈底部视图
- (void)popToRootViewController:(NSInteger)index
                       animated:(BOOL)animated
{
//    [self delayPopIgnore:YES];
    UINavigationController *nav = [self currentNavigationController];
    [nav popToRootViewControllerAnimated:animated];
    
    UIViewController *viewController = nav.topViewController;
    if ([viewController isKindOfClass:[UITabBarController class]]) {
        UITabBarController *tabbarController = (UITabBarController *)viewController;
        if (index < tabbarController.viewControllers.count) {
            tabbarController.selectedIndex = index;
            [tabbarController.delegate tabBarController:tabbarController didSelectViewController:tabbarController.viewControllers[index]];
        } else {
            // 最后一个tab
            tabbarController.selectedIndex = tabbarController.viewControllers.count-1;
            [tabbarController.delegate tabBarController:tabbarController didSelectViewController:tabbarController.viewControllers[tabbarController.viewControllers.count-1]];
        }
    }
}


#pragma mark - present视图控制器

// present视图控制器，根据类名
- (void)presentViewControllerWithName:(NSString *)name
{
    [self presentViewControllerWithName:name param:nil];
}

// present视图控制器，根据类名
- (void)presentViewControllerWithName:(NSString *)name
                                param:(NSDictionary *)param
{
    Class cls = NSClassFromString(name);
    [self presentViewControllerWithClass:cls param:param];
}

// present视图控制器，根据class
- (void)presentViewControllerWithClass:(Class)cls
{
    [self presentViewControllerWithClass:cls param:nil];
}

// present视图控制器，根据class
- (void)presentViewControllerWithClass:(Class)cls
                                 param:(NSDictionary *)param
{
    UIViewController *viewController = [self viewControllerWithClass:cls];
    [self presentViewController:viewController param:param];
}

// present视图控制器
- (void)presentViewController:(UIViewController *)viewController
{
    [self presentViewController:viewController param:nil];
}

// present视图控制器
- (void)presentViewController:(UIViewController *)viewController
                        param:(NSDictionary *)param
{
    [self presentViewController:viewController param:param animated:YES transparent:NO completion:nil];
}

// present视图控制器
- (void)presentViewController:(UIViewController *)viewController
                        param:(NSDictionary *)param
                     animated:(BOOL)animated
                  transparent:(BOOL)transparent
                   completion:(void (^ __nullable)(void))completion
{
    if (!viewController) {
        return;
    }
//    [self delayPopIgnore:NO];
    [self setupViewController:viewController param:param];
    
    STBaseNav *navigationViewController = [[STBaseNav alloc] initWithRootViewController:viewController];
    if (transparent) {
        navigationViewController.navigationBarHidden = YES;
        navigationViewController.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
        navigationViewController.providesPresentationContextTransitionStyle = YES;
        navigationViewController.definesPresentationContext = YES;
        navigationViewController.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    }
    self.presentContainerNav = navigationViewController;
    [self.navigationController presentViewController:self.presentContainerNav
                                            animated:animated
                                          completion:completion];
}


#pragma mark - dismiss视图控制器

// dismiss当前视图控制器(默认animated为YES)
- (void)dismissViewControllerCompletion:(void (^)(void))completion
{
    [self dismissViewControllerAnimated:YES completion:completion];
}

// dismiss当前视图控制器
- (void)dismissViewControllerAnimated:(BOOL)animated
                           completion:(void (^)(void))completion
{
//    [self delayPopIgnore:YES];
    __typeof__(self) __weak weakSelf = self;
    [self.navigationController dismissViewControllerAnimated:animated completion:^{
        weakSelf.presentContainerNav = nil;
        if (completion) {
            completion();
        }
    }];
}


#pragma mark - 工具方法

// 返回当前的导航控制器
- (UINavigationController *)currentNavigationController
{
    if (self.navigationController.presentedViewController
        && self.navigationController.presentedViewController == self.presentContainerNav)
    {
        return self.presentContainerNav;
    }
    return self.navigationController;
}

// 返回当前导航控制器栈顶的视图控制器
- (UIViewController *)topViewController
{
    UIViewController *topViewController = [self currentNavigationController].topViewController;
    return topViewController;
}

// 返回当前导航控制器栈中指定的视图控制器
- (UIViewController *)controllerInNavigationStackWithClass:(Class)cls
{
    UINavigationController *currentNav = [self currentNavigationController];
    for (UIViewController *viewController in currentNav.viewControllers) {
        if ([viewController isMemberOfClass:cls]) {
            return viewController;
        }
    }
    return nil;
}

// 返回当前present的视图控制器
- (UIViewController *)presentedViewController
{
    return self.navigationController.presentedViewController;
}


- (Class)parentViewControllerClass {
    UINavigationController *currentNav = [self currentNavigationController];
    NSUInteger count = currentNav.viewControllers.count;
    if (count > 1) {
        return [currentNav.viewControllers[count-2] class];
    } else {
        return nil;
    }
}

- (NSString*)currentPagePath {
    NSString *pagePath = @"";
    UINavigationController *currentNav = [self currentNavigationController];
    for (__strong UIViewController *viewController in currentNav.viewControllers) {
        if ([viewController isKindOfClass:[UITabBarController class]]) {
            UITabBarController *tabBar = viewController;
            viewController = tabBar.selectedViewController;
        }
        if ([viewController respondsToSelector:@selector(pageName)]) {
            pagePath = [NSString stringWithFormat:@"%@/%@",pagePath,[viewController valueForKey:@"pageName"]];
        }
    }
    return pagePath;
}

- (NSString*)parentPageName {
    NSString *lastPage = @"";
    UINavigationController *currentNav = [self currentNavigationController];
    NSUInteger count = currentNav.viewControllers.count;
    if (count > 1) {
        UIViewController *viewController = currentNav.viewControllers[count-2];
        if ([viewController isKindOfClass:[UITabBarController class]]) {
            UITabBarController *tabBar = viewController;
            viewController = tabBar.selectedViewController;
        }
        if ([viewController respondsToSelector:@selector(pageName)]) {
            lastPage = [viewController valueForKey:@"pageName"];
        }
    }
    
    return lastPage;
}

// 私有方法__根据class创建视图控制器
- (UIViewController *)viewControllerWithClass:(Class)cls
{
    UIViewController *viewController = nil;
    
    if (![cls isSubclassOfClass:[UIViewController class]]) {
        return nil;
    }
    if ([cls respondsToSelector:@selector(storyboadName)]) {
        NSString *storyboardName = [cls storyboadName];
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle:nil];
        viewController = [storyboard instantiateViewControllerWithIdentifier:NSStringFromClass(cls)];
    }
    else if ([cls respondsToSelector:@selector(xibName)]) {
        NSString *xibName = [cls xibName];
        viewController = [[cls alloc] initWithNibName:xibName bundle:nil];
    }
    else {
        viewController = [[cls alloc] init];
    }
    return viewController;
}

// 私有方法__设置视图控制器相关参数
- (void)setupViewController:(UIViewController *)viewController param:(NSDictionary *)param
{
    if ([param isKindOfClass:[NSDictionary class]] && param.count > 0) {
        //转化参数为property
        [self setupParamsForViewController:viewController params:param];
    }
    
    if ([viewController respondsToSelector:@selector(setFrontPageNameArray:)])
    {
        NSArray *pageNameArray = @[];
        UIViewController *topViewController = [[self currentNavigationController] topViewController];
        if ([topViewController isKindOfClass:[UITabBarController class]]) {
            UITabBarController *tabbarController = (UITabBarController *)topViewController;
            UIViewController *selectedViewController = tabbarController.selectedViewController;
            if ([selectedViewController respondsToSelector:@selector(pageNameArray)]) {
                pageNameArray = [selectedViewController performSelector:@selector(pageNameArray)];
            }
        }
        else if ([topViewController respondsToSelector:@selector(pageNameArray)]) {
            pageNameArray = [topViewController performSelector:@selector(pageNameArray)];
        }
        [viewController performSelector:@selector(setFrontPageNameArray:) withObject:pageNameArray];
    }
}

// 私有方法__设置视图控制器的property
- (void)setupParamsForViewController:(UIViewController *)targetViewController params:(NSDictionary *)params
{
    // paramDic里值的类型可能会和targetViewController属性匹配不上，比如属性是个NSNumber类型，而值是NSString
    // 为了避免这样的情况，在设置参数的时候，对于这两种类型做特殊处理
    NSMutableDictionary *prototypeParams = [NSMutableDictionary dictionary];
    
    [params enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
        if (![key isKindOfClass:[NSString class]]) {
            return;
        }
        if ([obj isKindOfClass:[NSString class]]
            || [obj isKindOfClass:[NSNumber class]])
        {
            prototypeParams[key] = obj;
            return;
        }
        NSString *upperKey = [key stringByReplacingCharactersInRange:NSMakeRange(0, 1) withString:[[key substringToIndex:1] uppercaseString]];
        
        SEL setMethod = NSSelectorFromString([NSString stringWithFormat:@"set%@:", upperKey]);
        if (![targetViewController respondsToSelector:setMethod]) {
            return;
        }
        [targetViewController setValue:obj forKeyPath:key];
    }];
    [targetViewController mj_setKeyValues:prototypeParams];
}



@end
