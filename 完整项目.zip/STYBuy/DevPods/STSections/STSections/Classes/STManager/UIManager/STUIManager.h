//
//  STUIManager.h
//  STSections
//
//  Created by 高欣 on 2019/2/24.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#define UIManager [STUIManager manager]

@protocol STUIManagerDelegate <NSObject>

@optional
/**
 *  如果页面通过storyboard创建，实现该方法，返回storyboard名
 *
 *  @return storyboard名
 */
+ (NSString *)storyboadName;

/**
 *  如果页面通过nib创建，实现该方法，返回storyboard名
 *
 *  @return nib名
 */
+ (NSString *)xibName;

@end


@interface STUIManager : NSObject
+ (instancetype)manager;

- (void)registerNavigationController:(UINavigationController *)navigationController;

#pragma mark - Push视图控制器

/**
 *  push视图控制器，根据类名
 *
 *  @param name 视图控制器类名
 */
- (void)showViewControllerWithName:(NSString *)name;

/**
 *  push视图控制器，根据类名
 *
 *  @param name  视图控制器类名
 *  @param param 视图控制器参数
 */
- (void)showViewControllerWithName:(NSString *)name
                             param:(NSDictionary *)param;

/**
 *  push视图控制器，根据类名
 *
 *  @param name     视图控制器类名
 *  @param param    视图控制器参数
 *  @param animated 是否带动画
 */
- (void)showViewControllerWithName:(NSString *)name
                             param:(NSDictionary *)param
                          animated:(BOOL)animated;

/**
 *  push视图控制器，根据class
 *
 *  @param cls 视图控制器class
 */
- (void)showViewControllerWithClass:(Class)cls;

/**
 *  push视图控制器，根据class
 *
 *  @param cls   视图控制器class
 *  @param param 视图控制器参数
 */
- (void)showViewControllerWithClass:(Class)cls
                              param:(NSDictionary *)param;

/**
 *  push视图控制器，根据class
 *
 *  @param cls      视图控制器class
 *  @param param    视图控制器参数
 *  @param animated 是否带动画
 */
- (void)showViewControllerWithClass:(Class)cls
                              param:(NSDictionary *)param
                           animated:(BOOL)animated;

/**
 *  push视图控制器
 *
 *  @param viewController 视图控制器
 */
- (void)showViewController:(UIViewController *)viewController;

/**
 *  push视图控制器
 *
 *  @param viewController 视图控制器
 *  @param param          视图控制器参数
 */
- (void)showViewController:(UIViewController *)viewController
                     param:(NSDictionary *)param;

/**
 *  push视图控制器
 *
 *  @param viewController 视图控制器
 *  @param param          视图控制器参数
 *  @param animated       是否带动画
 */
- (void)showViewController:(UIViewController *)viewController
                     param:(NSDictionary *)param
                  animated:(BOOL)animated;


#pragma mark - Pop视图控制器

/**
 *  pop当前视图控制器(默认animated为YES)
 *
 *  @return pop掉的视图控制器
 */
- (UIViewController *)popViewController;

/**
 *  pop当前视图控制器
 *
 *  @param animated 是否带动画
 *
 *  @return pop掉的视图控制器
 */
- (UIViewController *)popViewController:(BOOL)animated;

///**
// * pop当前视图控制器，如果没有紧接着的push时有动画效果，否则无动画,
// * 可用于pop后立即执行completion block，且无法确定block里是否有push的场景
// */
//- (void)popViewControllerAnimatedIfCan;

/**
 *  pop栈队列中指定视图(animated为YES)
 *
 *
 *  @return pop掉的视图控制器
 */
- (UIViewController *)popToViewController:(Class)cls;

/**
 *  pop栈队列中指定视图
 *
 *  @param animated            是否带动画
 *
 *  @return pop掉的视图控制器
 */
- (UIViewController *)popToViewController:(Class)cls
                                 animated:(BOOL)animated;

/**
 *  pop到栈底部视图(默认animated为NO)
 */
- (void)popToRoot;

/**
 *  pop到栈底部视图(默认animated为YES)
 *
 *  @param index tabbarController的索引值
 */
- (void)popToRootViewController:(NSInteger)index;

/**
 *  pop到栈底部视图
 *
 *  @param index    tabbarController的索引值
 *  @param animated 是否带动画
 */
- (void)popToRootViewController:(NSInteger)index
                       animated:(BOOL)animated;


#pragma mark - Present视图控制器

/**
 *  present视图控制器，根据类名
 *
 *  @param name 视图控制器类名
 */
- (void)presentViewControllerWithName:(NSString *)name;

/**
 *  present视图控制器，根据类名
 *
 *  @param name  视图控制器类名
 *  @param param 视图控制器参数
 */
- (void)presentViewControllerWithName:(NSString *)name
                                param:(NSDictionary *)param;

/**
 *  present视图控制器，根据class
 *
 *  @param cls 视图控制器class
 */
- (void)presentViewControllerWithClass:(Class)cls;

/**
 *  present视图控制器，根据class
 *
 *  @param cls   视图控制器class
 *  @param param 视图控制器参数
 */
- (void)presentViewControllerWithClass:(Class)cls
                                 param:(NSDictionary *)param;

/**
 *  present视图控制器
 *
 *  @param viewController 视图控制器
 */
- (void)presentViewController:(UIViewController *)viewController;

/**
 *  present视图控制器
 *
 *  @param viewController 视图控制器
 *  @param param          视图控制器参数
 */
- (void)presentViewController:(UIViewController *)viewController
                        param:(NSDictionary *)param;

/**
 *  present视图控制器,带动画
 *
 *  @param viewController 视图控制器
 *  @param param          视图控制器参数
 *  @param animated       是否开启动画
 */
- (void)presentViewController:(UIViewController *)viewController
                        param:(NSDictionary *)param
                     animated:(BOOL)animated
                  transparent:(BOOL)transparent
                   completion:(void (^ __nullable)(void))completion;

#pragma mark - Dismiss视图控制器

/**
 *  dismiss当前视图控制器(默认animated为YES)
 *
 *  @param completion dismiss完成后的回调block
 */
- (void)dismissViewControllerCompletion:(void (^)(void))completion;

/**
 *  dismiss当前视图控制器
 *
 *  @param animated   是否带动画
 *  @param completion dismiss完成后的回调block
 */
- (void)dismissViewControllerAnimated:(BOOL)animated
                           completion:(void (^)(void))completion;


#pragma mark - 工具方法

/**
 *  返回当前的导航视图控制器
 *
 *  @return 导航视图控制器
 */
- (UINavigationController *)currentNavigationController;

/**
 *  返回当前导航视图控制器栈顶的视图控制器
 *
 *  @return 顶层视图控制器
 */
- (UIViewController *)topViewController;

/**
 *  返回当前导航控制器栈中指定的视图控制器
 *
 *  @param cls 视图控制器class
 *
 *  @return 指定的视图控制器
 */
- (UIViewController *)controllerInNavigationStackWithClass:(Class)cls;

/**
 *  返回当前present的视图控制器
 *
 *  @return 视图控制器
 */
- (UIViewController *)presentedViewController;


/**
 返回navigation中上一级视图控制器class
 
 @return 视图控制器class
 */
- (Class)parentViewControllerClass;


/**
 返回页面路径
 */
- (NSString*)currentPagePath;
- (NSString*)parentPageName;

@end

NS_ASSUME_NONNULL_END
