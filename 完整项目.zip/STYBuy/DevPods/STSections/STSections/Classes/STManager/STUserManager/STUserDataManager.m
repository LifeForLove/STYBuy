//
//  STUserDataManager.m
//  STYBuy
//
//  Created by 高欣 on 2018/5/14.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#import "STUserDataManager.h"
#import "STUserData.h"


@interface STUserDataManager ()

@property (nonatomic,strong)  NSManagedObjectContext *context;//coredata上下文

@end


@implementation STUserDataManager

static STUser * _currentUser;

+ (instancetype)sharedUserManager
{
    static STUserDataManager *obj;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        obj = [[STUserDataManager alloc]init];
        //先从数据库读取数据
        STUser * currentUser = [obj currentUser];
        if (currentUser) {
            NSDictionary * dict = currentUser.mj_keyValues;
            obj.userData = [STUserData mj_objectWithKeyValues:dict];
        }else
        {
            obj.userData = [[STUserData alloc]init];
        }
        
        //监听数据是否改变 数据库实时同步
        [RACObserve(obj.userData, reloadData) subscribeNext:^(id x) {
            if ([x boolValue]) {
                [obj change:^(STUser *user) {
                    [user st_CopyModel:STCurrentUser];
                }];
            }
        }];
    });
    return obj;
}

- (void)insert:( void (^) (STUser *))userBlock
{
    if ([self userSaved]) {
        NSLog(@"数据库已有此用户");
        return;
    }
    
    STUser *users = [NSEntityDescription insertNewObjectForEntityForName:@"STUser" inManagedObjectContext:self.context];
    if (!userBlock) return;
    userBlock(users);

    NSError *error = nil;
    BOOL success = NO;
    if (self.context.hasChanges) {
        success = [self.context save:&error];
    }
    
    if (!success) {
        [NSException raise:@"访问数据库错误" format:@"%@", [error localizedDescription]];
        
    }else
    {
        NSLog(@"插入成功");
    }
    
}

- (void)change:(void (^)(STUser *))userBlock
{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"STUser"];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"userId = %@", _currentUser.userId];
    request.predicate = predicate;
    NSError *error = nil;
    NSArray<STUser *> *users = [self.context executeFetchRequest:request error:&error];
    
    if (users.count == 0) {
        //异常处理
        [self deleteUser];
        STUser * user = [self initializeSTUser];
        if (userBlock) {
            userBlock(user);
        }
    }else
    {
        if (!_currentUser) {
            _currentUser = users.firstObject;
        }
        for (STUser * user in users) {
            if (user == _currentUser) {
                if (userBlock) {
                    userBlock(user);
                    break;
                }
            }
        }
    }

    if (self.context.hasChanges) {
        [self.context save:nil];
    }
    if (error) {
        NSLog(@"CoreData Update Data Error : %@", error);
    }
}



- (void)deleteUser
{
    //删除之前首先需要用到查询
    NSFetchRequest *request = [[NSFetchRequest alloc] init]; //创建请求

    request.entity = [NSEntityDescription entityForName:@"STUser" inManagedObjectContext:self.context];//找到我们的Person

    NSError *error = nil;
    NSArray *objs = [self.context executeFetchRequest:request error:&error];//执行我们的请求
    if (error) {
        [NSException raise:@"查询错误" format:@"%@", [error localizedDescription]];//抛出异常
    }
    // 遍历数据
    for (STUser *obj in objs) {
        NSLog(@"userState = %@", [obj valueForKey:@"userState"]); //打印符合条件的数据
        NSLog(@"userId = %@", [obj valueForKey:@"userId"]); //打印符合条件的数据
        [self.context deleteObject:obj];
    }

    BOOL success = [self.context save:&error];
    if (!success) {
        [NSException raise:@"访问数据库错误" format:@"%@", [error localizedDescription]];
    }else
    {
        NSLog(@"删除成功，sqlite");
    }
}

/**
 初始化当前用户
 */
- (STUser *)initializeSTUser
{
    STUserData * use = [[STUserData alloc]init];
    [self insert:^(STUser *user) {
        //初始化
        user.userId = @(0);
        user.phone = use.phone;
        user.userState = @0;
        user.paypwd = use.paypwd;
        user.nickName = use.nickName;
        user.phone = use.phone;
        _currentUser = user;
    }];
    return _currentUser;
}

- (STUser *)currentUser
{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"STUser"];
    NSError *error = nil;
    NSArray<STUser *> *users = [self.context executeFetchRequest:request error:&error];
    if (users.count == 0) {
        return [self initializeSTUser];
    }else
    {
        if (!_currentUser) {
            _currentUser = users.firstObject;
        }
        for (STUser * user in users) {
            if (user == _currentUser) {
                return user;
            }
        }
    }

    if (error) {
        NSLog(@"CoreData Ergodic Data Error : %@", error);
    }
    //异常处理
    [self deleteUser];
    //创建一个新的用户
    return [self initializeSTUser];
}

- (BOOL)userSaved
{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"STUser"];
    NSError *error = nil;
    NSArray<STUser *> *users = [self.context executeFetchRequest:request error:&error];
    if (users.count > 0) {
        return YES;
    }
    if (error) {
        NSLog(@"CoreData Ergodic Data Error : %@", error);
    }
    return NO;
}

/**
 退出登录
 */
- (void)showAlert:(NSString *)string
{
    UIViewController *vc = [self getCurrentVC];
    
    if ([vc isKindOfClass:[UIAlertController class]]) {
        //判断是否有退出的弹窗
        UIAlertController * alertVc = (UIAlertController *)vc;
        if ([alertVc.message isEqualToString:string]) {
            return;
        }
    }
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:@"提示" message:string preferredStyle:UIAlertControllerStyleAlert];
    @weakify(self);
    [ac addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        @strongify(self);
        //退出的操作
        [self userLoginOutAction];
    }]];
    [vc presentViewController:ac animated:YES completion:nil];
}

/**
 退出登录
 */
- (void)userLoginOutAction
{
    /*
     退出接口请求成功之后
     1 清除用户信息
     2 发送通知 退到根视图刷新界面
     */
    
    NSString * longit = STCurrentUser.longitude;
    NSString * lati = STCurrentUser.latitude;
    
    STUserData * userdata = [[STUserData alloc]init];
    [STCurrentUser st_CopyModel:userdata];
    STCurrentUser.longitude = longit;
    STCurrentUser.latitude = lati;
    
    STCurrentUser.reloadData = YES;
    
//    //删除用户
//    [self deleteUser];
//    //生成新的用户
//    [self currentUser];
//    //直播退出登录
//    [STUserManager change:^(STUser *user) {
//        user.longitude = longit;
//        user.latitude = lati;
//    }];
    
    //发送退出成功的通知
    [STNotificationCenter postNotificationName:STLoginOutSuccessNotification object:nil];

}


- (void)loginOut:(void (^)(void))success fail:(void (^)(void))fail
{
    // 请求退出登录接口
    HUD_LOADTITLE(@"正在退出")
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        [self userLoginOutAction];
        if (success) {
            success();
        }
    });
}


- (NSManagedObjectContext *)context
{
    if (_context == nil) {
        _context = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
        
        NSURL *modelPath = [[NSBundle mainBundle] URLForResource:@"STSections.bundle/STUser" withExtension:@"momd"];
        NSManagedObjectModel *model = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelPath];
        
        NSPersistentStoreCoordinator *coordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:model];
        
        NSString *dataPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).lastObject;
        NSError *error = nil;
        dataPath = [dataPath stringByAppendingFormat:@"/%@.sqlite", @"STUserModel"];
        
        NSPersistentStore *store = [coordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL: [NSURL fileURLWithPath:dataPath] options:nil error:&error];
        if (store == nil) {
            
            
            NSDictionary *options = [NSDictionary dictionaryWithObjectsAndKeys:
                                     [NSNumber numberWithBool:YES], NSMigratePersistentStoresAutomaticallyOption,
                                     [NSNumber numberWithBool:YES], NSInferMappingModelAutomaticallyOption,                             nil];
            store = [coordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:[NSURL fileURLWithPath:dataPath] options:options error:&error];
            
            if (store == nil) {
                // 直接抛异常
                [NSException raise:@"添加数据库错误" format:@"%@", [error localizedDescription]];
            }
        }
        
        _context.persistentStoreCoordinator = coordinator;
        NSLog(@"%@",NSHomeDirectory());//数据库会存在沙盒目录的Documents文件夹下
    }
    return _context;
}


@end
