//
//  STUserDataManager.h
//  STYBuy
//
//  Created by 高欣 on 2018/5/14.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "STUser+CoreDataClass.h"
#import "STUserData.h"
#define STUserManager [STUserDataManager sharedUserManager]
#define STCurrentUser STUserManager.userData

@interface STUserDataManager : NSObject

/**
 用户数据
 */
@property (nonatomic,strong) STUserData * userData;

/**
 单例
 */
+(instancetype)sharedUserManager;

/**
 退出登录
 */
- (void)showAlert:(NSString *)string;

/**
 退出登录
 */
- (void)loginOut:(void(^)(void))success fail:(void(^)(void))fail;

@end
