//
//  STAppManager.h
//  STSections
//
//  Created by 高欣 on 2019/2/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface STAppConstructorInfo : NSObject

@property (nonatomic,copy) NSString *className;
@property (nonatomic,copy) NSString *image;
@property (nonatomic,copy) NSString *selectImage;
@property (nonatomic,copy) NSString *title;


@end


@interface STAppManager : NSObject

@property (nonatomic,strong) STRootNavController *rootNavController;
@property (nonatomic,strong) STMainTab *mainTab;

+ (instancetype)manager;

- (STRootNavController *)constructUI;

@end

NS_ASSUME_NONNULL_END
