//
//  STAppManager.m
//  STSections
//
//  Created by 高欣 on 2019/2/19.
//

#import "STAppManager.h"
#import "STErrorViewController.h"

@interface STAppManager ()

@end

@implementation STAppManager

+ (instancetype)manager
{
    static STAppManager * obj;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        obj = [[STAppManager alloc]init];
        obj.rootNavController = [[STRootNavController alloc]init];
        obj.mainTab = [[STMainTab alloc]init];
        [obj requestModuleInfo];
        [[STNotificationCenter rac_addObserverForName:STConstructorUINotification object:nil]subscribeNext:^(NSNotification *noti) {
            [obj requestModuleInfo];
        }];
    });
    return obj;
}

- (STRootNavController *)constructUI
{
    [self.rootNavController setViewControllers:@[self.mainTab] animated:NO];
    return self.rootNavController;
}

- (void)requestModuleInfo
{
    NSMutableArray * mouduleArr = [NSMutableArray array];
    STAppConstructorInfo * home = [[STAppConstructorInfo alloc]init];
    home.className = @"STHomeVC";
    home.image = @"tabbar_home_n";
    home.selectImage = @"tabbar_home_s";
    home.title = @"首页";
    
    STAppConstructorInfo * order = [[STAppConstructorInfo alloc]init];
    order.className = @"STOrderVC";
    order.image = @"tabbar_dd_n";
    order.selectImage = @"tabbar_dd_s";
    order.title = @"订单";
    
    STAppConstructorInfo * mine = [[STAppConstructorInfo alloc]init];
    mine.className = @"STMineVC";
    mine.image = @"tabbar_mine_n";
    mine.selectImage = @"tabbar_mine_s";
    mine.title = @"我的";
    
    [mouduleArr addObject:home];
    [mouduleArr addObject:order];
    [mouduleArr addObject:mine];

    [self configTabBar:mouduleArr];
    
}

- (void)configTabBar:(NSMutableArray *)moduleArr
{
    NSMutableArray * vcs = [NSMutableArray array];
    for (STAppConstructorInfo * model in moduleArr) {
        Class class = NSClassFromString(model.className);
        if ([class isSubclassOfClass:[UIViewController class]]) {
            UIViewController * vc = [[NSClassFromString(model.className) alloc]init];
            vc.title = model.title;
            vc.tabBarItem = [[UITabBarItem alloc]initWithTitle:model.title image:[UIImage imageNamed:model.image] selectedImage:[UIImage imageNamed:model.selectImage]];
//            [vc.tabBarItem setTitleTextAttributes:@{NSForegroundColorAttributeName:Main_Color ,NSFontAttributeName:TabbarTextFont} forState:UIControlStateSelected];
//            [vc.tabBarItem setTitleTextAttributes:@{NSForegroundColorAttributeName:Text_Gary_Color,NSFontAttributeName:TabbarTextFont} forState:UIControlStateNormal];
            [vcs addObject:vc];
        }else
        {
            UIViewController * vc = [[STErrorViewController alloc]init];
            vc.title = model.title;
            vc.tabBarItem = [[UITabBarItem alloc]initWithTitle:model.title image:[[UIImage imageNamed:model.image]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] selectedImage:[[UIImage imageNamed:model.selectImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
//            [vc.tabBarItem setTitleTextAttributes:@{NSForegroundColorAttributeName:Main_Color ,NSFontAttributeName:TabbarTextFont} forState:UIControlStateSelected];
//            [vc.tabBarItem setTitleTextAttributes:@{NSForegroundColorAttributeName:Text_Gary_Color,NSFontAttributeName:TabbarTextFont} forState:UIControlStateNormal];
            [vcs addObject:vc];
        }
    }
    self.mainTab.navigationItem.title = @"首页";
    self.mainTab.viewControllers = vcs;
}



@end

@implementation STAppConstructorInfo

@end
