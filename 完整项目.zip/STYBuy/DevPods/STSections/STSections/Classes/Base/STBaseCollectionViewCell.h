//
//  STBaseCollectionViewCell.h
//  STYBuy
//
//  Created by 高欣 on 2019/1/5.
//  Copyright © 2019年 getElementByYou. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface STBaseCollectionViewCell : UICollectionViewCell
- (void)createView;
- (void)configTarget;
@end

NS_ASSUME_NONNULL_END
