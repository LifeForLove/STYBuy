//
//  STBaseTableViewModel.h
//  STYBuy
//
//  Created by 高欣 on 2019/1/12.
//  Copyright © 2019年 getElementByYou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "STBaseVC.h"
NS_ASSUME_NONNULL_BEGIN

@interface STTabCellIdentiModel : NSObject

@property (nonatomic,copy) NSString *cellClassName;

@property (nonatomic,copy) NSString *cellIdenti;

+ (STTabCellIdentiModel *)st_createCellIdentiModel:(NSString *)cellClassName cellIdentify:(NSString *)cellIdentify;
@end

@interface STBaseTableViewModel : NSObject

@property (nonatomic,weak) STBaseVC *st_vmVc;

@property (nonatomic,weak) UITableView *st_vmTab;

@property (nonatomic,strong) NSMutableArray * st_infoArr;

- (void)st_configTargetWithTab:(UITableView *)tableView viewController:(STBaseVC *)vc;
/**
 cell中的操作
 */
- (void)st_configCellTarget:(UITableViewCell *)cell IndexPath:(NSIndexPath *)indexPath;

- (void)st_configSelectIndexPath:(NSIndexPath *)indexPath;

- (void)st_viewDidLoad;

@end

NS_ASSUME_NONNULL_END
