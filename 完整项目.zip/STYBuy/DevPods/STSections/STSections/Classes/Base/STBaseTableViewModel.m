//
//  STBaseTableViewModel.m
//  STYBuy
//
//  Created by 高欣 on 2019/1/12.
//  Copyright © 2019年 getElementByYou. All rights reserved.
//

#import "STBaseTableViewModel.h"

@implementation STBaseTableViewModel

- (void)st_configTargetWithTab:(UITableView *)tableView viewController:(STBaseVC *)vc
{
    self.st_vmTab = tableView;
    self.st_vmVc = vc;
}

- (void)st_configCellTarget:(UITableViewCell *)cell IndexPath:(NSIndexPath *)indexPath{};

- (void)st_configSelectIndexPath:(NSIndexPath *)indexPath{}

- (void)st_viewDidLoad{};

@end


@implementation STTabCellIdentiModel

+ (STTabCellIdentiModel *)st_createCellIdentiModel:(NSString *)cellClassName cellIdentify:(NSString *)cellIdentify
{
    STTabCellIdentiModel * model = [[STTabCellIdentiModel alloc]init];
    model.cellClassName = cellClassName;
    model.cellIdenti = cellIdentify;
    return model;
}
@end
