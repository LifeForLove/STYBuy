//
//  STBaseCollectionViewCell.m
//  STYBuy
//
//  Created by 高欣 on 2019/1/5.
//  Copyright © 2019年 getElementByYou. All rights reserved.
//

#import "STBaseCollectionViewCell.h"

@implementation STBaseCollectionViewCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        [self createView];
        [self configTarget];
    }
    return self;
}

- (void)createView{}
- (void)configTarget{}

@end
