//
//  STWebViewController.m
//  STYBuy
//
//  Created by 高欣 on 2019/1/13.
//  Copyright © 2019年 getElementByYou. All rights reserved.
//

#import "STWebViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>

@interface STWebViewController () <UIWebViewDelegate>
@property (nonatomic, strong) NSURLRequest *request;
@end

@implementation STWebViewController

- (void)dealloc {
    [self.webView stopLoading];
    self.webView.delegate = nil;
    self.delegate = nil;
    _webView = nil;
}


- (instancetype)initWithAddress:(NSString *)urlString {
    return [self initWithURL:[NSURL URLWithString:urlString]];
}

- (instancetype)initWithURL:(NSURL*)pageURL {
    return [self initWithURLRequest:[NSURLRequest requestWithURL:pageURL]];
}

- (instancetype)initWithURLRequest:(NSURLRequest*)request {
    self = [super init];
    if (self) {
        self.request = request;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.webView];

    @weakify(self);
    self.navigationItem.leftBarButtonItem  = [UIBarButtonItem st_customNavBarButton:@"back" clickBlock:^(UIButton * _Nonnull sender) {
        @strongify(self);
        [self navLeftPressed];
    }];
    [self loadRequest:self.request];
}

- (BOOL)canPopViewController {
    if ([self.webView canGoBack]) {
        [self.webView goBack];
        [self addCloseButton];
        return NO;
    } else {
        return YES;
    }
}

- (void)addCloseButton {
    if (!self.navigationItem.rightBarButtonItem) {
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"关闭" style:UIBarButtonItemStyleDone target:self action:@selector(handleCloseButtonEvent)];
    }
}

- (void)handleCloseButtonEvent {
    [self.navigationController popViewControllerAnimated:YES];
}

//用苹果自带的返回键按钮处理如下(自定义的返回按钮)
- (void)navLeftPressed{
    self.navigationController.interactivePopGestureRecognizer.delegate = (id)self;
    self.navigationController.interactivePopGestureRecognizer.enabled = YES;
    if ([self.webView canGoBack]) {
        [self.webView goBack];
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark - UIWebViewDelegate's method
- (void)webViewDidStartLoad:(UIWebView *)webView{
    if ([self.delegate respondsToSelector:@selector(webViewDidStartLoad:)]) {
        [self.delegate webViewDidStartLoad:webView];
    }
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    if (self.title.length == 0) {
        self.title = [self.webView stringByEvaluatingJavaScriptFromString:@"document.title"];
    }
    if ([self.delegate respondsToSelector:@selector(webViewDidFinishLoad:)]) {
        [self.delegate webViewDidFinishLoad:webView];
    }
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    if ([self.delegate respondsToSelector:@selector(webView:didFailLoadWithError:)]) {
        [self.delegate webView:webView didFailLoadWithError:error];
    }
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    if ([self.delegate respondsToSelector:@selector(webView:shouldStartLoadWithRequest:navigationType:)]) {
        return [self.delegate webView:webView shouldStartLoadWithRequest:request navigationType:navigationType];
    }
    return YES;
}

#pragma mark - Private methods
- (void)loadRequest:(NSURLRequest*)request {
    [self.webView loadRequest:request];
}


#pragma mark - Getters

- (UIWebView*)webView {
    if(!_webView) {
        _webView = [[UIWebView alloc] initWithFrame:self.view.bounds];
        _webView.delegate = self;
        _webView.allowsInlineMediaPlayback = YES;
        _webView.backgroundColor = Background_Color;
    }
    return _webView;
}

@end


