//
//  STBaseTableViewController.m
//  STYBuy
//
//  Created by 高欣 on 2019/1/13.
//  Copyright © 2019年 getElementByYou. All rights reserved.
//

#import "STBaseTableViewController.h"

@interface STBaseTableViewController ()

@end

@implementation STBaseTableViewController

- (void)st_configTabelViewType:(UITableViewStyle)tableViewType viewModel:(STBaseTableViewModel *)viewModel
{
    if (tableViewType == UITableViewStylePlain) {
        self.tableView = self.st_TableView;
    }else
    {
        self.tableView = self.st_GroupTableView;
    }
    self.viewModel = viewModel;
    if(viewModel) [viewModel st_configTargetWithTab:self.tableView viewController:self];
    [self.view addSubview:self.tableView];
    self.tableView.frame = CGRectMake(0, 1, kScreenWidth, kScreenHeight - 1 - SafeAreaNavHeight);
    [self st_configTableViewStyle:self.tableView];
    if(viewModel) [viewModel st_viewDidLoad];
}

- (void)st_configTableViewStyle:(UITableView *)tableView{}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.viewModel) {
        [self.viewModel st_configSelectIndexPath:indexPath];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 0;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.000001;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.000001;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 0;
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section
{
    if ([view isKindOfClass: [UITableViewHeaderFooterView class]]) {
        UITableViewHeaderFooterView * castView = (UITableViewHeaderFooterView*) view;
        UIView* content = castView.contentView;
        content.backgroundColor = self.tableView.backgroundColor;
    }
}

- (void)tableView:(UITableView *)tableView willDisplayFooterView:(UIView *)view forSection:(NSInteger)section
{
    if ([view isKindOfClass: [UITableViewHeaderFooterView class]]) {
        UITableViewHeaderFooterView * castView = (UITableViewHeaderFooterView*) view;
        UIView* content = castView.contentView;
        content.backgroundColor = self.tableView.backgroundColor;
    }
}


@end
