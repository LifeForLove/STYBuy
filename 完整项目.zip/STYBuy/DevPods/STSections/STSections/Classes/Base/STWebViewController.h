//
//  STWebViewController.h
//  STYBuy
//
//  Created by 高欣 on 2019/1/13.
//  Copyright © 2019年 getElementByYou. All rights reserved.
//

#import "STBaseVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface STWebViewController : STBaseVC
@property (nonatomic, strong) UIWebView *webView;
@property (nonatomic, weak) id<UIWebViewDelegate> delegate;

/**
 * 初始化一个WebViewController。
 */
- (instancetype)initWithAddress:(NSString*)urlString;
- (instancetype)initWithURL:(NSURL*)URL;
- (instancetype)initWithURLRequest:(NSURLRequest *)request;



@end


NS_ASSUME_NONNULL_END
