//
//  STErrorViewController.m
//  STHomeVC
//
//  Created by 高欣 on 2019/2/23.
//

#import "STErrorViewController.h"

@interface STErrorViewController ()

@end

@implementation STErrorViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self st_configTabelViewType:UITableViewStylePlain viewModel:nil];
    [self scrollViewConfigRequestStateForEmptyView:self.tableView error:nil CustomEmptyType:STEmptyType_Error_Null];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.emptyView bindSelectorForButton:@selector(requestData) target:self];
    self.tableView.frame = CGRectMake(0, 0, kScreenWidth, kScreenHeight - SafeAreaNavHeight - SafeAreaBarIncreaseHeight);
}

/**
 刷新页面
 */
- (void)requestData
{
    NSLog(@"重新请求刷新页面");
}

@end
