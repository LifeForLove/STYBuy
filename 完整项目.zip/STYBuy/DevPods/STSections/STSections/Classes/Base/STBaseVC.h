//
//  STBaseVC.h
//  STYBuy
//
//  Created by 高欣 on 2018/5/12.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "STEmptyView.h"
@class STTabCellIdentiModel;
@interface STBaseVC : UIViewController

@property (nonatomic,assign) BOOL navHidden;

/**
 手势侧滑返回
 */
@property (nonatomic,assign) BOOL gesturesToBack;

/**
 传值模型
 */
@property (nonatomic,strong) id st_Model;

/**
 返回按钮的点击事件
 */
- (void)backAction;

/**
 返回
 */
- (void)st_popBack;

/**
 打开web页面
 
 @param url web连接
 */
- (void)st_openWkWebViewWithURL:(NSString *)url;

/**
 去App Store升级app
 */
- (void)goAppStroe;

/**
 设置导航栏颜色
 
 @param navColor 导航栏颜色
 @param tintColor 导航栏文字颜色
 */
- (void)configNavColor:(UIColor *)navColor tintColor:(UIColor *)tintColor;

// 默认样式
- (void)configNavThemeStyle;

@end
