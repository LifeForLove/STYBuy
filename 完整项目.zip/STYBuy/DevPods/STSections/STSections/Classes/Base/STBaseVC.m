//
//  STBaseVC.m
//  STYBuy
//
//  Created by 高欣 on 2018/5/12.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#import "STBaseVC.h"
#import "STWebViewController.h"
@interface STBaseVC ()

@end

@implementation STBaseVC

- (void)viewDidLoad {
    [super viewDidLoad];
    //设置背景颜色
    self.view.backgroundColor = Background_Color;
    
    if (@available(iOS 11.0, *)) {
    } else {
        // Fallback on earlier versions
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    
    //如果是栈顶控制器 就不加返回按钮
    if (self != self.navigationController.viewControllers.firstObject) {
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"back"] style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];
    }
    //设置侧滑返回
    self.navigationController.interactivePopGestureRecognizer.delegate = (id)self;
    
//    [[STNotificationCenter rac_addObserverForName:STChangeThemeNotification object:nil]subscribeNext:^(id x) {
//        [instance configTheme];
//    }];

}

- (void)setNavHidden:(BOOL)navHidden
{
    self.navigationController.navigationBar.hidden = navHidden;
}

- (void)setGesturesToBack:(BOOL)gesturesToBack
{
    if([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.enabled = gesturesToBack;
    }
}


- (void)backAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/**
 去App Store升级app
 */
- (void)goAppStroe
{
    
}

/**
 打开web页面

 @param url web连接
 */
- (void)st_openWkWebViewWithURL:(NSString *)url
{
    STWebViewController * vc = [[STWebViewController alloc]initWithURL:[NSURL URLWithString:url]];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)st_popBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 设置导航栏颜色
 
 @param navColor 导航栏颜色
 @param tintColor 导航栏文字颜色
 */
- (void)configNavColor:(UIColor *)navColor tintColor:(UIColor *)tintColor
{
    //nav 文字颜色
    if (tintColor) [self.navigationController.navigationBar setTintColor:tintColor];
    //导航栏的颜色
    if (navColor) [self.navigationController.navigationBar setBackgroundImage:[UIImage createImageWithColor:navColor] forBarMetrics:UIBarMetricsDefault];
}

- (void)configNavThemeStyle
{
    //nav 文字颜色
    [self.navigationController.navigationBar setTintColor:Text_Black_Color];
    //导航栏背景颜色
    [self.navigationController.navigationBar setBackgroundImage:[UIImage createImageWithColor:White_Color] forBarMetrics:UIBarMetricsDefault];
}


@end
