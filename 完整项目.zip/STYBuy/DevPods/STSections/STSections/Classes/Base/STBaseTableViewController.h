//
//  STBaseTableViewController.h
//  STYBuy
//
//  Created by 高欣 on 2019/1/13.
//  Copyright © 2019年 getElementByYou. All rights reserved.
//

#import "STBaseVC.h"
#import "STBaseTableViewModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface STBaseTableViewController : STBaseVC

@property (nonatomic,weak) UITableView *tableView;

@property (nonatomic,strong) STBaseTableViewModel * viewModel;

@property (nonatomic,strong) NSArray<STTabCellIdentiModel *> *identiArr;

/**
 建立view 与viewModel之间的联系 并添加tableView

 @param tableViewType tableViewType
 @param viewModel viewModel
 */
- (void)st_configTabelViewType:(UITableViewStyle)tableViewType viewModel:(nullable STBaseTableViewModel *)viewModel;

/**
 配置tableView的样式/注册cell 子类重写

 @param tableView tableView
 */
- (void)st_configTableViewStyle:(UITableView *)tableView;

@end

NS_ASSUME_NONNULL_END
