//
//  STKey.h
//  STYBuy
//
//  Created by 高欣 on 2018/12/26.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#ifndef STKey_h
#define STKey_h

#ifdef DEBUG

#define BuglyAppID @"762b786afb" //测试

#else

#define BuglyAppID @"d2e0690302" //线上

#endif

#endif /* STKey_h */
