//
//  STNotification.h
//  STYBuy
//
//  Created by 高欣 on 2018/5/13.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#ifndef STNotification_h
#define STNotification_h

//设置根视图的通知
static NSString * const STConstructorUINotification = @"STConstructorUINotification";
//更改主题的通知
static NSString * const STChangeThemeNotification = @"STChangeThemeNotification";

//刷新一级界面的通知
static NSString *const STRefreshHomeDataNotification = @"STRefreshHomeDataNotification";
//成功退出登录的通知
static NSString *const STLoginOutSuccessNotification = @"STLoginOutSuccessNotification";

#endif /* STNotification_h */
