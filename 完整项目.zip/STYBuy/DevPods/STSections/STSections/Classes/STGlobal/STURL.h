//
//  STURL.h
//  STYBuy
//
//  Created by 高欣 on 2018/5/12.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#ifndef STURL_h
#define STURL_h


#define REQUESTURL(url)  [NSString stringWithFormat:@"%@%@",HMGlobal.BASE_URL,url]

#endif /* STURL_h */
