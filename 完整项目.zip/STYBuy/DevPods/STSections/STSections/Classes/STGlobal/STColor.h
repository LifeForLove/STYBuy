//
//  STColor.h
//  STYBuy
//
//  Created by 高欣 on 2018/5/12.
//  Copyright © 2018年 getElementByYou. All rights reserved.
//

#ifndef STColor_h
#define STColor_h

#define rgba(r,g,b,a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

/**
 背景色
 */
#define Background_Color [UIColor colorWithRed:245/255.0 green:245/255.0 blue:245/255.0 alpha:1]

/**
 白色
 */
#define White_Color [UIColor whiteColor]

/**
 主题色
 */
#define Main_Color STTheme.mainColor

/**
 文字深黑 #333333
 */
#define  Text_Black_Color [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1]

/**
 文字灰 #666666
 */
#define Text_Gary_Color [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1]

/**
 很淡很淡浅灰色 #999999
 */
#define Text_DHS_Color [UIColor colorWithRed:153/255.0 green:153/255.0 blue:153/255.0 alpha:1]

/**
 分割线的颜色 #EEEEEE
 */
#define Line_DHS_Color UIColorHex(EEEEEE)


#endif /* STColor_h */
