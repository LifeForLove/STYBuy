//
//  HMGlobalFile.m
//  TianYiMerchant
//
//  Created by 高欣 on 2018/11/29.
//  Copyright © 2018年 HLM. All rights reserved.
//

#import "HMGlobalFile.h"

@implementation HMGlobalFile

+ (instancetype)shareGlobal
{
    static HMGlobalFile * obj;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        obj = [[HMGlobalFile alloc]init];
        NSString * baseUrl = [[NSUserDefaults standardUserDefaults]objectForKey:ServiceURL_Key];
        if (!baseUrl) {
            [[NSUserDefaults standardUserDefaults]setObject:@"http://api.budejie.com/" forKey:ServiceURL_Key];
        }
        obj.BASE_URL = [[NSUserDefaults standardUserDefaults]objectForKey:ServiceURL_Key];
        obj.IMG_URL = @"";
        obj.NOTICE_URL = @"";
    });
    return obj;
}


@end
