//
//  CTMediator+STOrderModuleActions.h
//  STOrderVC
//
//  Created by 高欣 on 2019/3/2.
//

#import "CTMediator.h"

NS_ASSUME_NONNULL_BEGIN

@interface CTMediator (STOrderModuleActions)

- (UIViewController *)CTMediator_OrderPayViewController:(NSDictionary *)params;

@end

NS_ASSUME_NONNULL_END
