//
//  CTMediator+STOrderModuleActions.m
//  STOrderVC
//
//  Created by 高欣 on 2019/3/2.
//

#import "CTMediator+STOrderModuleActions.h"
#import "STErrorViewController.h"

NSString * const kCTMediatorTargetOrderVC = @"OrderVC";
NSString * const kCTMediatorActionNativFetchOrderPayVC = @"OrderPayViewController";

@implementation CTMediator (STOrderModuleActions)

- (UIViewController *)CTMediator_OrderPayViewController:(NSDictionary *)params
{
    UIViewController *vc = [self performTarget:kCTMediatorTargetOrderVC action:kCTMediatorActionNativFetchOrderPayVC params:params shouldCacheTarget:NO];
    if ([vc isKindOfClass:[UIViewController class]]) {
        return vc;
    }else
    {
        return [[STErrorViewController alloc]init];
    }
}


@end
