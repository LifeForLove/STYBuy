//
//  UITableView+Footer.h
//  Gafaer
//
//  Created by apple on 2017/8/21.
//  Copyright © 2017年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum : NSUInteger {
    FootType_button = 0,
} FootType;

@interface UITableView (Footer)

@property (nonatomic, assign) FootType footType;

@property (nonatomic, readonly) UIView *footView;

@property (nonatomic, readonly) UIButton *footBtn;

@property (nonatomic, copy) NSString *footTitle;

@end
