//
//  UITableView+Footer.m
//  Gafaer
//
//  Created by apple on 2017/8/21.
//  Copyright © 2017年 apple. All rights reserved.
//

#import "UITableView+Footer.h"
#import <objc/runtime.h>

static char const * const FooterType = "FooterType";
static char const * const FooterBtn = "FooterBtn";
static char const * const FooterView = "FooterView";

#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define FootBtn_W kScreenWidth - 45 * 2

@implementation UITableView (Footer)

@dynamic footView,footType,footBtn;

- (void)setFootType:(FootType)footType
{
    NSNumber * number = [NSNumber numberWithInteger:footType];
    objc_setAssociatedObject(self, FooterType, number, OBJC_ASSOCIATION_ASSIGN);
    
    if (footType == FootType_button) {
        self.footView.frame = CGRectMake(0, 0, kScreenWidth, 100);
        [self.footView addSubview:self.footBtn];
        self.tableFooterView = self.footView;
        [self.footBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(self.footView);
            make.size.mas_equalTo(CGSizeMake(FootBtn_W , 40));
        }];
    }
}

- (FootType)footType
{
    NSNumber *number = objc_getAssociatedObject(self, FooterType);
    return [number integerValue];
}

- (UIView *)footView
{
    UIView * footView = objc_getAssociatedObject(self, FooterView);
    if (!footView) {
        footView = [[UIView alloc]init];
        footView.backgroundColor = self.backgroundColor;
        objc_setAssociatedObject(self, FooterView , footView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    return footView;
}

- (UIButton *)footBtn
{
    UIButton * footBtn = objc_getAssociatedObject(self, FooterBtn);
    if (!footBtn) {
        footBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [footBtn setBackgroundImage:[UIImage createImageWithColor:Main_Color] forState:UIControlStateNormal];
        footBtn.titleLabel.font = Font(15);
        footBtn.layer.cornerRadius = 4;
        footBtn.layer.masksToBounds = YES;
        objc_setAssociatedObject(self, FooterBtn, footBtn, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    return footBtn;
}

- (void)setFootTitle:(NSString *)footTitle
{
    [self.footBtn setTitle:footTitle forState:UIControlStateNormal];
}
- (NSString *)footTitle
{
    return self.footBtn.titleLabel.text;
}

@end
