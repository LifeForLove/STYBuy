//
//  STUserData.h
//  STSections
//
//  Created by 高欣 on 2019/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface STUserData : NSObject

/**
 经纬度
 */
@property (nullable, nonatomic, copy) NSString *latitude;
@property (nullable, nonatomic, copy) NSString *longitude;

/**
 昵称
 */
@property (nullable, nonatomic, copy) NSString *nickName;

/**
 登录密码
 */
@property (nullable, nonatomic, copy) NSString *paypwd;

/**
 手机号
 */
@property (nullable, nonatomic, copy) NSString *phone;

/**
 用户id
 */
@property (nullable, nonatomic, copy) NSNumber *userId;

/**
 用户登录状态
 */
@property (nullable, nonatomic, copy) NSNumber *userState;

/**
 用户头像
 */
@property (nullable, nonatomic, copy) NSString *logo;

/**
 当用户信息发生变化时将此值赋为yes 监听该值的状态就能做到实时同步
 */
@property (nonatomic,assign) BOOL reloadData;

@end

NS_ASSUME_NONNULL_END
