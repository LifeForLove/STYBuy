//
//  STUser+CoreDataProperties.h
//  
//
//  Created by 高欣 on 2019/3/3.
//
//

#import "STUser+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface STUser (CoreDataProperties)

+ (NSFetchRequest<STUser *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *latitude;
@property (nullable, nonatomic, copy) NSString *longitude;
@property (nullable, nonatomic, copy) NSString *nickName;
@property (nullable, nonatomic, copy) NSString *paypwd;
@property (nullable, nonatomic, copy) NSString *phone;
@property (nullable, nonatomic, strong) NSNumber *userId;
@property (nullable, nonatomic, strong) NSNumber *userState;
@property (nullable, nonatomic, copy) NSString *logo;

@end

NS_ASSUME_NONNULL_END
