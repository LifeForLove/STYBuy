//
//  STUser+CoreDataProperties.m
//  
//
//  Created by 高欣 on 2019/3/3.
//
//

#import "STUser+CoreDataProperties.h"

@implementation STUser (CoreDataProperties)

+ (NSFetchRequest<STUser *> *)fetchRequest {
	return [NSFetchRequest fetchRequestWithEntityName:@"STUser"];
}

@dynamic latitude;
@dynamic longitude;
@dynamic nickName;
@dynamic paypwd;
@dynamic phone;
@dynamic userId;
@dynamic userState;
@dynamic logo;

@end
