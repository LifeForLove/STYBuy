//
//  STUser+CoreDataClass.m
//  
//
//  Created by 高欣 on 2019/3/3.
//
//

#import "STUser+CoreDataClass.h"

@implementation STUser

//找未找到的Key
- (id)valueForUndefinedKey:(NSString *)key
{
    NSLog(@"Undefined Key: %@",key);
    return nil;
}
//设置未找到的Key
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"Undefined Key: %@",key);
}

@end
