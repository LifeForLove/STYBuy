//
//  STLoginVC.h
//  STMineVC
//
//  Created by 高欣 on 2019/3/3.
//

#import "STBaseVC.h"

NS_ASSUME_NONNULL_BEGIN
typedef void(^resultBlock)(NSInteger code);
@interface STLoginVC : STBaseVC
@property (nonatomic,copy) resultBlock result;
/**
 展示登录界面
 
 @param result 回调登录结果
 */
+ (void)show:(resultBlock)result;
@end

NS_ASSUME_NONNULL_END
