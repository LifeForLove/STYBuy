//
//  main.m
//  STSections
//
//  Created by LifeForLove on 02/17/2019.
//  Copyright (c) 2019 LifeForLove. All rights reserved.
//

@import UIKit;
#import "STAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([STAppDelegate class]));
    }
}
