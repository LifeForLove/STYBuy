//
//  STHomeVC.m
//  STHomeVC
//
//  Created by 高欣 on 2019/2/23.
//

#import "STHomeVC.h"
#import "STHomeViewModel.h"
#import "STFoodListCell.h"
#import "STFoodCategoryModel.h"

static NSString * const STFoodListCellIdentifi = @"STFoodListCellIdentifi";
@interface STHomeVC ()

@end

@implementation STHomeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    STHomeViewModel * viewModel = [[STHomeViewModel alloc]init];
    [self st_configTabelViewType:UITableViewStylePlain viewModel:viewModel];
}

- (void)st_configTableViewStyle:(UITableView *)tableView
{
    tableView.frame = CGRectMake(0, 0, kScreenWidth, kScreenHeight - SafeAreaTabbarHeight - 1);
    tableView.separatorColor = UIColorHex(#EEEEEE);
    [tableView registerClass:[STFoodListCell class] forCellReuseIdentifier:STFoodListCellIdentifi];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    STFoodListCell * cell = [tableView dequeueReusableCellWithIdentifier:STFoodListCellIdentifi];
    STHomeViewModel * viewModel = (STHomeViewModel *)self.viewModel;
    STFoodModel * model = viewModel.foodData[indexPath.section][indexPath.row];
    [cell.imageV sd_setImageWithURL:[NSURL URLWithString:model.picture]];
    cell.nameLabel.text = model.name;
    cell.priceLabel.text = Money_Unit_ToString(model.min_price);
    cell.contentLabel.text = @"月销9999";
    [self.viewModel st_configCellTarget:cell IndexPath:indexPath];
    return  cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    STHomeViewModel * viewModel = (STHomeViewModel *)self.viewModel;
    NSInteger count = [viewModel.foodData[section] count];
    return count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    STHomeViewModel * viewModel = (STHomeViewModel *)self.viewModel;
    NSInteger count = [viewModel.categoryData count];
    return count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 120;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    STHomeViewModel * viewModel = (STHomeViewModel *)self.viewModel;
    UILabel * sectionL = [UILabel labelWithColor:UIColorHex(#333333) font:Font(15) alignment:NSTextAlignmentCenter title:viewModel.categoryData[section].name?:@""];
    sectionL.frame = CGRectMake(0, 0, kScreenWidth, 44);
    sectionL.backgroundColor = self.tableView.backgroundColor;
    return sectionL;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 44;
}


@end
