//
//  STFoodCategoryModel.m
//  STHomeVC
//
//  Created by 高欣 on 2019/2/23.
//

#import "STFoodCategoryModel.h"

@implementation STFoodCategoryModel

+ (NSDictionary *)objectClassInArray
{
    return @{ @"spus": @"STFoodModel" };
}

@end

@implementation STFoodModel

+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{ @"foodId": @"id" };
}


@end
