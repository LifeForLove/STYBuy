//
//  STFoodListCell.m
//  STHomeVC
//
//  Created by 高欣 on 2019/2/23.
//

#import "STFoodListCell.h"

@interface STFoodListCell ()


@end

@implementation STFoodListCell

- (void)createView
{
    [self.contentView addSubview:self.imageV];
    [self.contentView addSubview:self.nameLabel];
    [self.contentView addSubview:self.contentLabel];
    [self.contentView addSubview:self.priceLabel];
    [self.contentView addSubview:self.recommendLabel];
    
    [self.imageV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(77);
        make.centerY.equalTo(self.contentView);
        make.left.equalTo(@10);
    }];
    
    [self.nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.imageV.mas_right).offset(10);
        make.top.equalTo(self.imageV).offset(-5);
        make.right.equalTo(self.contentView).offset(-15);
        make.height.mas_lessThanOrEqualTo(36);
    }];
    
    [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.nameLabel.mas_bottom).offset(2);
        make.left.equalTo(self.nameLabel);
    }];
    
    [self.recommendLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.nameLabel);
        make.top.equalTo(self.contentLabel.mas_bottom).offset(2);
    }];
    
    [self.priceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.contentView).offset(-8);
        make.left.equalTo(self.nameLabel);
    }];
}

- (void)configTarget
{
    
}


- (UIImageView *)imageV
{
    if (_imageV == nil) {
        _imageV = [[UIImageView alloc]init];
        _imageV.backgroundColor = Background_Color;
    }
    return _imageV;
}

- (UILabel *)nameLabel
{
    if (_nameLabel == nil) {
        _nameLabel = [UILabel labelWithColor:Text_Black_Color font:BoldFont(16) alignment:NSTextAlignmentLeft title:@""];
        _nameLabel.numberOfLines = 2;
    }
    return _nameLabel;
}

- (UILabel *)contentLabel
{
    if (_contentLabel == nil) {
        _contentLabel = [UILabel labelWithColor:Text_DHS_Color font:BoldFont(11) alignment:NSTextAlignmentLeft title:@""];
    }
    return _contentLabel;
}

- (UILabel *)priceLabel
{
    if (_priceLabel == nil) {
        _priceLabel = [UILabel labelWithColor:UIColorHex(#FF0915) font:BoldFont(16) alignment:NSTextAlignmentLeft title:@""];
    }
    return _priceLabel;
}

- (SFLabel *)recommendLabel
{
    if (_recommendLabel == nil) {
        _recommendLabel = [[SFLabel alloc]init];
        _recommendLabel.font = Font(10);
        _recommendLabel.textColor = UIColorHex(#FF6532);
        _recommendLabel.layer.cornerRadius = 2;
        _recommendLabel.layer.masksToBounds = YES;
        _recommendLabel.layer.borderWidth = 0.5;
        _recommendLabel.layer.borderColor = _recommendLabel.textColor.CGColor;
        _recommendLabel.edgeInsets = UIEdgeInsetsMake(0, 5, 0, 5);
        _recommendLabel.text = @"店长推荐";
    }
    return _recommendLabel;
}

@end
