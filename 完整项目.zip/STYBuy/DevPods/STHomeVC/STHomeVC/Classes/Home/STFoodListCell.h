//
//  STFoodListCell.h
//  STHomeVC
//
//  Created by 高欣 on 2019/2/23.
//

#import <STSections/STSections.h>

NS_ASSUME_NONNULL_BEGIN

@interface STFoodListCell : STBaseTableViewCell
/**
 图片
 */
@property (nonatomic,strong) UIImageView *imageV;

/**
 名称
 */
@property (nonatomic,strong) UILabel *nameLabel;

/**
 内容
 */
@property (nonatomic,strong) UILabel *contentLabel;

/**
 价格
 */
@property (nonatomic,strong) UILabel *priceLabel;

/**
 推荐
 */
@property (nonatomic,strong) SFLabel *recommendLabel;

@end

NS_ASSUME_NONNULL_END
