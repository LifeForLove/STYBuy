//
//  STHomeViewModel.m
//  STHomeVC
//
//  Created by 高欣 on 2019/2/23.
//

#import "STHomeViewModel.h"
#import "STFoodCategoryModel.h"
#import "STFoodListCell.h"

@implementation STHomeViewModel

- (void)st_viewDidLoad
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"STHomeVC.bundle/meituan" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    NSArray *foods = dict[@"data"][@"food_spu_tags"];
    
    for (int a = 0; a < foods.count; a++)
    {
        NSDictionary *dict = foods[a];
        STFoodCategoryModel *model = [STFoodCategoryModel mj_objectWithKeyValues:dict];
        [self.categoryData addObject:model];
        
        NSMutableArray *datas = [NSMutableArray array];
        for (int i = 0; i < model.spus.count; i++) {
            STFoodModel * f_model = model.spus[i];
            [datas addObject:f_model];
        }
        [self.foodData addObject:datas];
    }
    
    [self.st_vmTab reloadData];
}

- (void)st_configCellTarget:(UITableViewCell *)cell IndexPath:(NSIndexPath *)indexPath
{
    if ([cell isKindOfClass:[STFoodListCell class]]) {
        
        
    }
}

- (void)st_configSelectIndexPath:(NSIndexPath *)indexPath
{
    STFoodModel * model = self.foodData[indexPath.section][indexPath.row];
    UIViewController * vc = [[CTMediator sharedInstance]CTMediator_OrderPayViewController:@{@"foodId":model.foodId,@"name":model.name}];
    [UIManager showViewController:vc];
}


- (NSMutableArray *)categoryData
{
    if (_categoryData == nil) {
        _categoryData = [NSMutableArray array];
    }
    return _categoryData;
}

- (NSMutableArray *)foodData
{
    if (_foodData == nil) {
        _foodData = [NSMutableArray array];
    }
    return _foodData;
}


@end
