//
//  STHomeVC.h
//  STHomeVC
//
//  Created by 高欣 on 2019/2/23.
//

#import "STBaseTableViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface STHomeVC : STBaseTableViewController

@end

NS_ASSUME_NONNULL_END
