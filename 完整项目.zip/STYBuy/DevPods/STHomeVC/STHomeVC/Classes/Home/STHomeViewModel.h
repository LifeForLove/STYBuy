//
//  STHomeViewModel.h
//  STHomeVC
//
//  Created by 高欣 on 2019/2/23.
//

#import "STBaseTableViewModel.h"

NS_ASSUME_NONNULL_BEGIN
@class STFoodCategoryModel;
@interface STHomeViewModel : STBaseTableViewModel

@property (nonatomic,strong) NSMutableArray<STFoodCategoryModel *> *categoryData;

@property (nonatomic,strong) NSMutableArray * foodData;

@end

NS_ASSUME_NONNULL_END
