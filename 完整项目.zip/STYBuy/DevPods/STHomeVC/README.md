# STHomeVC

[![CI Status](https://img.shields.io/travis/LifeForLove/STHomeVC.svg?style=flat)](https://travis-ci.org/LifeForLove/STHomeVC)
[![Version](https://img.shields.io/cocoapods/v/STHomeVC.svg?style=flat)](https://cocoapods.org/pods/STHomeVC)
[![License](https://img.shields.io/cocoapods/l/STHomeVC.svg?style=flat)](https://cocoapods.org/pods/STHomeVC)
[![Platform](https://img.shields.io/cocoapods/p/STHomeVC.svg?style=flat)](https://cocoapods.org/pods/STHomeVC)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

STHomeVC is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'STHomeVC'
```

## Author

LifeForLove, getElementByYou@163.com

## License

STHomeVC is available under the MIT license. See the LICENSE file for more info.
